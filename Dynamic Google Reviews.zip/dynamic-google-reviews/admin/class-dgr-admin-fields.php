<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/class-dgr-admin-field-schema.php';

class DGR_Admin_Fields {
    private static function render_description( $text ) {
        if ( '' === (string) $text ) {
            return '';
        }

        return '<p class="description">' . esc_html( $text ) . '</p>';
    }

    private static function render_text_from_schema( $field, $value ) {
        $schema = DGR_Admin_Field_Schema::get( $field );
        printf(
            '<input type="text" name="%1$s[%2$s]" value="%3$s" class="%4$s" />%5$s',
            esc_attr( DGR_Config::OPTION_KEY ),
            esc_attr( $schema['field'] ),
            esc_attr( $value ),
            esc_attr( isset( $schema['class'] ) ? $schema['class'] : 'regular-text' ),
            self::render_description( isset( $schema['description'] ) ? $schema['description'] : '' )
        );
    }

    private static function render_number_from_schema( $field, $value ) {
        $schema      = DGR_Admin_Field_Schema::get( $field );
        $attrs       = '';
        $description = isset( $schema['description'] ) ? $schema['description'] : '';

        if ( 'min_rating' === $field ) {
            $description .= ( '' === $description ? '' : ' ' ) . __( 'Filtering reviews by minimum rating may conflict with Google review-snippet policy.', 'dynamic-google-reviews' );
        }

        if ( ! empty( $schema['attrs'] ) && is_array( $schema['attrs'] ) ) {
            foreach ( $schema['attrs'] as $attr_name => $attr_value ) {
                $attrs .= sprintf( ' %s="%s"', esc_attr( $attr_name ), esc_attr( $attr_value ) );
            }
        }

        printf(
            '<input type="number"%1$s name="%2$s[%3$s]" value="%4$d" />%5$s',
            // $attrs is assembled only from esc_attr()-escaped schema attribute names and values above.
            $attrs,
            esc_attr( DGR_Config::OPTION_KEY ),
            esc_attr( $schema['field'] ),
            (int) $value,
            self::render_description( $description )
        );
    }

    private static function render_select_from_schema( $field, $value ) {
        $schema = DGR_Admin_Field_Schema::get( $field );
        ?>
        <select name="<?php echo esc_attr( DGR_Config::OPTION_KEY ); ?>[<?php echo esc_attr( $schema['field'] ); ?>]">
            <?php foreach ( $schema['options'] as $option_value => $option_label ) : ?>
                <option value="<?php echo esc_attr( $option_value ); ?>" <?php selected( $value, $option_value ); ?>><?php echo esc_html( $option_label ); ?></option>
            <?php endforeach; ?>
        </select>
        <?php echo self::render_description( isset( $schema['description'] ) ? $schema['description'] : '' ); ?>
        <?php
    }


    private static function render_textarea_from_schema( $field, $value ) {
        $schema = DGR_Admin_Field_Schema::get( $field );
        printf(
            '<textarea name="%1$s[%2$s]" rows="%3$s" cols="%4$s">%5$s</textarea>%6$s',
            esc_attr( DGR_Config::OPTION_KEY ),
            esc_attr( $schema['field'] ),
            esc_attr( isset( $schema['rows'] ) ? $schema['rows'] : '3' ),
            esc_attr( isset( $schema['cols'] ) ? $schema['cols'] : '40' ),
            esc_textarea( $value ),
            self::render_description( isset( $schema['description'] ) ? $schema['description'] : '' )
        );
    }

    private static function render_checkbox_from_schema( $field, $checked_value ) {
        $schema = DGR_Admin_Field_Schema::get( $field );
        printf(
            '<label><input type="checkbox" name="%1$s[%2$s]" value="1" %3$s /> %4$s</label>%5$s',
            esc_attr( DGR_Config::OPTION_KEY ),
            esc_attr( $schema['field'] ),
            checked( 1, $checked_value ? 1 : 0, false ),
            esc_html( $schema['label'] ),
            self::render_description( isset( $schema['description'] ) ? $schema['description'] : '' )
        );
    }

    private static function render_simple_field( $field ) {
        $schema = DGR_Admin_Field_Schema::get( $field );
        $value  = DGR_Admin_Field_Schema::get_current_value( $field, DGR_Config::OPTION_KEY );

        switch ( $schema['type'] ) {
            case 'number':
                self::render_number_from_schema( $field, $value );
                return;

            case 'select':
                self::render_select_from_schema( $field, $value );
                return;

            case 'textarea':
                self::render_textarea_from_schema( $field, $value );
                return;

            case 'checkbox':
                self::render_checkbox_from_schema( $field, $value );
                return;

            case 'text':
            default:
                self::render_text_from_schema( $field, $value );
                return;
        }
    }

    public static function render_schema_field( $args = [] ) {
        if ( ! is_array( $args ) || empty( $args['field'] ) ) {
            return;
        }

        self::render_simple_field( (string) $args['field'] );
    }

    public static function render_field_selected_pages() {
        $selected = DGR_Settings::get_selected_pages( DGR_Config::OPTION_KEY );

        $pages = get_pages( [ 'sort_column' => 'post_title' ] );
        printf( '<p><small>%1$s</small></p>', esc_html__( 'Only used when "Add to multiple pages" is enabled.', 'dynamic-google-reviews' ) );
        printf( '<select name="%1$s[selected_pages][]" multiple="multiple" size="8" style="min-width:320px;">', esc_attr( DGR_Config::OPTION_KEY ) );
        foreach ( $pages as $p ) {
            printf(
                '<option value="%1$d" %2$s>%3$s</option>',
                intval( $p->ID ),
                // The selected attribute fragment is a hard-coded value with no user input.
                in_array( intval( $p->ID ), $selected, true ) ? 'selected="selected"' : '',
                esc_html( sprintf( __( '%1$s (ID:%2$d)', 'dynamic-google-reviews' ), $p->post_title, intval( $p->ID ) ) )
            );
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__( 'Select pages to include rich data on', 'dynamic-google-reviews' ) . '</p>';
    }

    public static function render_field_remove_tokens() {
        $nonce = wp_create_nonce( 'dgr_remove_tokens_action' );
        printf(
            '<button type="submit" name="dgr_remove_tokens" value="1" class="button">%1$s</button> <input type="hidden" name="dgr_remove_tokens_nonce" value="%2$s" />' .
            '<p class="description">%3$s</p>',
            esc_html__( 'Remove stored tokens', 'dynamic-google-reviews' ),
            esc_attr( $nonce ),
            esc_html__( 'Click to remove stored Google OAuth tokens.', 'dynamic-google-reviews' )
        );
    }
}

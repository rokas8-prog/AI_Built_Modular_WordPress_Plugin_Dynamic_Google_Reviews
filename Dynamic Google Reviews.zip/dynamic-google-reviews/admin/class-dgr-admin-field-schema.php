<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DGR_Admin_Field_Schema {
    public static function get( $field ) {
        $schema = self::all();
        return isset( $schema[ $field ] ) ? $schema[ $field ] : null;
    }

    public static function fields_for_registration() {
        $fields = [];

        foreach ( self::all() as $field => $definition ) {
            if ( empty( $definition['register'] ) || 'remove_tokens' === $field ) {
                continue;
            }

            $fields[ $field ] = isset( $definition['registration_order'] ) ? (int) $definition['registration_order'] : 999;
        }

        asort( $fields, SORT_NUMERIC );

        return array_keys( $fields );
    }


    public static function get_current_value( $field, $option_key ) {
        $schema  = self::get( $field );
        $default = isset( $schema['default'] ) ? $schema['default'] : '';

        if ( ! empty( $schema['getter'] ) && is_callable( [ 'DGR_Settings', $schema['getter'] ] ) ) {
            if ( ! empty( $schema['passes_default'] ) ) {
                return call_user_func( [ 'DGR_Settings', $schema['getter'] ], $option_key, $default );
            }

            return call_user_func( [ 'DGR_Settings', $schema['getter'] ], $option_key );
        }

        return DGR_Settings::get_setting( $option_key, $field, $default );
    }

    public static function all() {
        return DGR_Field_Registry::get_schema_fields();
    }

}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$notice                       = $data['notice'] ?? null;
$persistent_notices           = isset( $data['persistent_notices'] ) && is_array( $data['persistent_notices'] ) ? $data['persistent_notices'] : [];
$tokens                       = $data['tokens'] ?? [];
$last                         = $data['last'] ?? '';
$auth_url                     = $data['auth_url'] ?? '';
$auth_error                   = $data['auth_error'] ?? '';
$page_title                   = $data['page_title'] ?? '';
$save_changes                 = $data['save_changes'] ?? '';
$tokens_stored                = $data['tokens_stored'] ?? '';
$last_successful_fetch        = $data['last_successful_fetch'] ?? '';
$get_authorization_code       = $data['get_authorization_code'] ?? '';
$force_fetch_text             = $data['force_fetch_text'] ?? '';
$force_fetch_button           = $data['force_fetch_button'] ?? '';
$test_connection_text         = $data['test_connection_text'] ?? '';
$test_connection_button       = $data['test_connection_button'] ?? '';
$test_connection_result       = $data['test_connection_result'] ?? [];
$test_connection_label        = $data['test_connection_label'] ?? '';
$fetch_status                 = $data['fetch_status'] ?? [];
$last_fetch_status            = $data['last_fetch_status'] ?? '';
$force_fetch_action_url       = $data['force_fetch_action_url'] ?? '';
$debug_place_shortcode        = $data['debug_place_shortcode'] ?? '';
$debug_place_shortcode_suffix = $data['debug_place_shortcode_suffix'] ?? '';

foreach ( $persistent_notices as $persistent ) {
    if ( ! is_array( $persistent ) || empty( $persistent['msg'] ) ) {
        continue;
    }
    echo '<div class="' . esc_attr( $persistent['class'] ?? 'error' ) . '"><p>' . esc_html( $persistent['msg'] ) . '</p></div>';
}

if ( is_array( $notice ) && ! empty( $notice['msg'] ) ) {
    echo '<div class="' . esc_attr( $notice['class'] ?? 'error' ) . '"><p>' . esc_html( $notice['msg'] ) . '</p></div>';
}

if ( is_array( $fetch_status ) && ! empty( $fetch_status['status'] ) ) {
    $status_class = 'success' === $fetch_status['status'] ? 'notice-success' : 'notice-error';
    echo '<div class="notice ' . esc_attr( $status_class ) . ' inline"><p><strong>' . esc_html( $last_fetch_status ) . '</strong> ' . esc_html( ucfirst( $fetch_status['status'] ) );
    if ( ! empty( $fetch_status['time'] ) ) {
        echo ' — ' . esc_html( $fetch_status['time'] );
    }
    if ( ! empty( $fetch_status['message'] ) ) {
        echo '<br>' . esc_html( $fetch_status['message'] );
    }
    if ( ! empty( $fetch_status['code'] ) ) {
        echo '<br><code>' . esc_html( $fetch_status['code'] ) . '</code>';
    }
    echo '</p></div>';
}

if ( is_array( $test_connection_result ) && ! empty( $test_connection_result ) ) {
    $tc_class = ! empty( $test_connection_result['ok'] ) ? 'notice-success' : 'notice-error';
    echo '<div class="notice ' . esc_attr( $tc_class ) . ' inline"><p><strong>' . esc_html( $test_connection_label ) . '</strong> ';
    echo esc_html( ! empty( $test_connection_result['ok'] ) ? __( 'OK', 'dynamic-google-reviews' ) : __( 'Failed', 'dynamic-google-reviews' ) );
    if ( ! empty( $test_connection_result['time'] ) ) {
        echo ' — ' . esc_html( $test_connection_result['time'] );
    }
    if ( ! empty( $test_connection_result['message'] ) ) {
        echo '<br>' . esc_html( $test_connection_result['message'] );
    }
    if ( ! empty( $test_connection_result['code'] ) ) {
        echo '<br><code>' . esc_html( $test_connection_result['code'] ) . '</code>';
    }
    echo '</p></div>';
}
?>
<div class="wrap" style="position:relative;">
    <h1 style="margin-top:24px;"><?php echo esc_html( $page_title ); ?></h1>

    <form method="post" action="options.php" style="margin-top:12px;">
        <?php
            settings_fields( 'dgr_bp_group' );
            do_settings_sections( 'dgr-bp-settings' );
            submit_button( esc_html( $save_changes ) );
        ?>
        <?php if ( ! empty( $tokens['access_token'] ) ) : ?>
            <p style="color:green;"><?php echo esc_html( $tokens_stored ); ?></p>
            <?php if ( $last ) : ?>
                <p><?php echo esc_html( $last_successful_fetch ); ?>
                    <strong><?php echo esc_html( $last ); ?></strong></p>
            <?php endif; ?>
        <?php else : ?>
            <?php if ( ! empty( $auth_url ) ) : ?>
                <p><a class="button button-primary" href="<?php echo esc_url( $auth_url ); ?>"><?php echo esc_html( $get_authorization_code ); ?></a></p>
            <?php else : ?>
                <p style="color:red;"><?php echo esc_html( $auth_error ); ?></p>
            <?php endif; ?>
        <?php endif; ?>
    </form>

    <form method="post" action="<?php echo esc_url( $force_fetch_action_url ); ?>" style="margin-top:12px;">
        <?php DGR_Admin_Fields::render_field_remove_tokens(); ?>
    </form>

    <form method="post" action="<?php echo esc_url( $force_fetch_action_url ); ?>" style="margin-top:12px;">
        <input type="hidden" name="<?php echo esc_attr( DGR_Config::FORCE_FETCH_PARAM ); ?>" value="1">
        <?php wp_nonce_field( DGR_Config::FORCE_FETCH_NONCE_ACTION, DGR_Config::FORCE_FETCH_NONCE_PARAM ); ?>
        <p><?php echo esc_html( $force_fetch_text ); ?>
            <button type="submit" class="button"><?php echo esc_html( $force_fetch_button ); ?></button>
        </p>
    </form>

    <form method="post" action="<?php echo esc_url( $force_fetch_action_url ); ?>" style="margin-top:12px;">
        <input type="hidden" name="<?php echo esc_attr( DGR_Admin_Controller::TEST_CONNECTION_PARAM ); ?>" value="1">
        <?php wp_nonce_field( DGR_Admin_Controller::TEST_CONNECTION_NONCE_ACTION, DGR_Admin_Controller::TEST_CONNECTION_NONCE_PARAM ); ?>
        <p><?php echo esc_html( $test_connection_text ); ?>
            <button type="submit" class="button"><?php echo esc_html( $test_connection_button ); ?></button>
        </p>
    </form>

    <p><?php echo esc_html( $debug_place_shortcode ); ?>
        <code>[dgr_debug_reviews]</code>
        <?php echo esc_html( $debug_place_shortcode_suffix ); ?>
    </p>
</div>

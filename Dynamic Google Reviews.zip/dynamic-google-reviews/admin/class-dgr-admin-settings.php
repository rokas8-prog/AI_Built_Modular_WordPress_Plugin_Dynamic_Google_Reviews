<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DGR_Admin_Settings {
    public static function register_hooks() {
        add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
    }

    public static function register_settings() {
        register_setting( 'dgr_bp_group', DGR_Config::OPTION_KEY, [ __CLASS__, 'sanitize_settings' ] );

        add_settings_section(
            'dgr_bp_main_section',
            __( 'Google Business Profile Credentials', 'dynamic-google-reviews' ),
            null,
            'dgr-bp-settings'
        );

        foreach ( DGR_Admin_Field_Schema::fields_for_registration() as $field ) {
            $definition = DGR_Admin_Field_Schema::get( $field );
            self::register_schema_field( $field, $definition );
        }
    }

    private static function register_schema_field( $field, $definition ) {
        if ( empty( $definition['title'] ) ) {
            return;
        }

        if ( ! empty( $definition['render_callback'] ) ) {
            $callback = $definition['render_callback'];
        } elseif ( isset( $definition['type'] ) && 'custom' === $definition['type'] ) {
            $callback = [ 'DGR_Admin_Fields', 'render_field_' . $field ];
        } else {
            $callback = [ 'DGR_Admin_Fields', 'render_schema_field' ];
        }

        $args = [
            'field' => $field,
        ];
        if ( ! empty( $definition['row_class'] ) ) {
            $args['class'] = $definition['row_class'];
        }

        add_settings_field(
            $field,
            $definition['title'],
            $callback,
            'dgr-bp-settings',
            'dgr_bp_main_section',
            $args
        );
    }

    public static function sanitize_settings( $input ) {
        $previous_fetch_interval = DGR_Settings::get_fetch_interval( DGR_Config::OPTION_KEY );
        $rules_by_field          = [];

        foreach ( DGR_Admin_Field_Schema::all() as $field => $definition ) {
            $rules = isset( $definition['sanitize'] ) && is_array( $definition['sanitize'] ) ? $definition['sanitize'] : [];

            if ( empty( $rules['stored'] ) ) {
                continue;
            }

            if ( ! array_key_exists( 'default', $rules ) && array_key_exists( 'default', $definition ) ) {
                $rules['default'] = $definition['default'];
            }

            $rules_by_field[ $field ] = $rules;
        }

        $settings = DGR_Settings::normalize_settings_values( $input, $rules_by_field, 'write' );
        $new_fetch_interval = isset( $settings['fetch_interval'] ) ? DGR_Settings::normalize_fetch_interval( $settings['fetch_interval'] ) : $previous_fetch_interval;

        if ( $new_fetch_interval !== $previous_fetch_interval && class_exists( 'DGR_Business_Profile' ) ) {
            DGR_Business_Profile::reschedule_fetch_event( $new_fetch_interval );
        }

        return $settings;
    }
}

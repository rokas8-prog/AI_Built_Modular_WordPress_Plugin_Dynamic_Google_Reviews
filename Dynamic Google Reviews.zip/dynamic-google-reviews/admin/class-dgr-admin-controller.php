<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once dirname( __DIR__ ) . '/includes/class-dgr-config.php';
require_once dirname( __DIR__ ) . '/includes/class-dgr-settings.php';
require_once dirname( __DIR__ ) . '/includes/class-dgr-runtime.php';
require_once dirname( __DIR__ ) . '/includes/class-dgr-fetch-service.php';
require_once __DIR__ . '/class-dgr-admin-notices.php';

class DGR_Admin_Controller {

    const FORCE_FETCH_LOCK_TRANSIENT     = 'dgr_bp_force_fetch_lock';
    const TEST_CONNECTION_PARAM          = 'dgr_test_connection';
    const TEST_CONNECTION_NONCE_PARAM    = 'dgr_tc_nonce';
    const TEST_CONNECTION_NONCE_ACTION   = 'dgr_bp_test_connection';
    const TEST_CONNECTION_RESULT_OPTION  = 'dgr_bp_last_test_connection';
    const TEST_CONNECTION_LOCK_TRANSIENT = 'dgr_bp_test_connection_lock';

    public static function register_hooks() {
        add_action( 'admin_menu', [ __CLASS__, 'add_settings_page' ] );
        add_action( 'admin_init', [ __CLASS__, 'maybe_handle_remove_tokens' ] );
        add_action( 'admin_init', [ __CLASS__, 'maybe_force_fetch' ] );
        add_action( 'admin_init', [ __CLASS__, 'maybe_test_connection' ] );
    }

    public static function add_settings_page() {
        add_options_page(
            __( 'Google Reviews Settings', 'dynamic-google-reviews' ),
            __( 'Google Reviews', 'dynamic-google-reviews' ),
            'manage_options',
            'dgr-bp-settings',
            [ __CLASS__, 'render_settings_page' ]
        );
    }

    public static function maybe_force_fetch() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( ! DGR_Settings::has_request_param( 'post', DGR_Config::FORCE_FETCH_PARAM ) || '1' !== DGR_Settings::get_request_text( 'post', DGR_Config::FORCE_FETCH_PARAM ) ) {
            return;
        }

        if ( ! DGR_Settings::has_request_param( 'post', DGR_Config::FORCE_FETCH_NONCE_PARAM ) ) {
            DGR_Admin_Notices::set_notice( 'error', __( 'Failed to verify request.', 'dynamic-google-reviews' ) );
            return;
        }

        $nonce = DGR_Settings::get_request_text( 'post', DGR_Config::FORCE_FETCH_NONCE_PARAM );
        if ( ! wp_verify_nonce( $nonce, DGR_Config::FORCE_FETCH_NONCE_ACTION ) ) {
            DGR_Admin_Notices::set_notice( 'error', __( 'Failed to verify request.', 'dynamic-google-reviews' ) );
            return;
        }

        if ( get_transient( self::FORCE_FETCH_LOCK_TRANSIENT ) ) {
            return;
        }
        set_transient( self::FORCE_FETCH_LOCK_TRANSIENT, 1, 30 );

        DGR_Runtime::force_fetch_reviews();

        DGR_Admin_Notices::set_notice( 'updated', __( 'Forced review fetch executed.', 'dynamic-google-reviews' ) );
    }

    public static function maybe_test_connection() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( ! DGR_Settings::has_request_param( 'post', self::TEST_CONNECTION_PARAM ) || '1' !== DGR_Settings::get_request_text( 'post', self::TEST_CONNECTION_PARAM ) ) {
            return;
        }

        if ( ! DGR_Settings::has_request_param( 'post', self::TEST_CONNECTION_NONCE_PARAM ) ) {
            DGR_Admin_Notices::set_notice( 'error', __( 'Failed to verify request.', 'dynamic-google-reviews' ) );
            return;
        }

        $nonce = DGR_Settings::get_request_text( 'post', self::TEST_CONNECTION_NONCE_PARAM );
        if ( ! wp_verify_nonce( $nonce, self::TEST_CONNECTION_NONCE_ACTION ) ) {
            DGR_Admin_Notices::set_notice( 'error', __( 'Failed to verify request.', 'dynamic-google-reviews' ) );
            return;
        }

        if ( get_transient( self::TEST_CONNECTION_LOCK_TRANSIENT ) ) {
            return;
        }
        set_transient( self::TEST_CONNECTION_LOCK_TRANSIENT, 1, 15 );

        $result = DGR_Runtime::test_connection();

        update_option(
            self::TEST_CONNECTION_RESULT_OPTION,
            [
                'ok'      => ! empty( $result['ok'] ),
                'code'    => isset( $result['code'] ) ? sanitize_key( $result['code'] ) : '',
                'http'    => isset( $result['http'] ) ? intval( $result['http'] ) : 0,
                'message' => isset( $result['message'] ) ? sanitize_text_field( $result['message'] ) : '',
                'time'    => current_time( 'mysql' ),
            ],
            false
        );

        DGR_Admin_Notices::set_notice(
            ! empty( $result['ok'] ) ? 'updated' : 'error',
            ! empty( $result['ok'] )
                ? __( 'Connection test succeeded.', 'dynamic-google-reviews' )
                : __( 'Connection test failed. See details below.', 'dynamic-google-reviews' )
        );
    }

    public static function maybe_handle_remove_tokens() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( ! DGR_Settings::has_request_param( 'post', 'dgr_remove_tokens' ) ) {
            return;
        }

        if ( ! DGR_Settings::has_request_param( 'post', 'dgr_remove_tokens_nonce' ) || ! wp_verify_nonce( DGR_Settings::get_request_text( 'post', 'dgr_remove_tokens_nonce' ), 'dgr_remove_tokens_action' ) ) {
            DGR_Admin_Notices::set_notice( 'error', __( 'Failed to verify request.', 'dynamic-google-reviews' ) );
            return;
        }

        DGR_Token_Storage::delete( DGR_Config::TOKEN_KEY );
        DGR_Admin_Notices::set_notice( 'updated', __( 'Stored tokens removed.', 'dynamic-google-reviews' ) );
    }

    public static function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $tokens     = DGR_Settings::get_tokens( DGR_Config::TOKEN_KEY );
        $last       = DGR_Settings::get_last_fetch( DGR_Config::LAST_FETCH_KEY );
        $notice     = DGR_Admin_Notices::consume_notice();
        $persistent = DGR_Admin_Notices::get_persistent_notices();
        $auth       = DGR_Runtime::build_auth_url();
        $auth_url   = $auth['url'];
        $auth_error = $auth['error'];

        $data = [
            'notice'                       => $notice,
            'persistent_notices'           => $persistent,
            'tokens'                       => $tokens,
            'last'                         => $last,
            'auth_url'                     => $auth_url,
            'auth_error'                   => $auth_error,
            'page_title'                   => __( 'Google Reviews Settings', 'dynamic-google-reviews' ),
            'save_changes'                 => __( 'Save Changes', 'dynamic-google-reviews' ),
            'tokens_stored'                => __( 'You already have tokens stored.', 'dynamic-google-reviews' ),
            'last_successful_fetch'        => __( 'Last successful fetch:', 'dynamic-google-reviews' ),
            'get_authorization_code'       => __( 'Get Authorization Code from Google', 'dynamic-google-reviews' ),
            'force_fetch_text'             => __( 'Force a fresh fetch:', 'dynamic-google-reviews' ),
            'force_fetch_button'           => __( 'Force fetch now', 'dynamic-google-reviews' ),
            'test_connection_text'         => __( 'Verify your credentials with a single read-only request:', 'dynamic-google-reviews' ),
            'test_connection_button'       => __( 'Test connection', 'dynamic-google-reviews' ),
            'test_connection_result'       => self::get_last_test_connection_result(),
            'test_connection_label'        => __( 'Last connection test:', 'dynamic-google-reviews' ),
            'debug_place_shortcode'        => __( 'Debug: place shortcode', 'dynamic-google-reviews' ),
            'debug_place_shortcode_suffix' => __( 'on a private page to inspect what is stored and applied.', 'dynamic-google-reviews' ),
            'fetch_status'                 => DGR_Settings::get_last_fetch_outcome(),
            'last_fetch_status'            => __( 'Last fetch status:', 'dynamic-google-reviews' ),
            'force_fetch_action_url'       => admin_url( 'options-general.php?page=dgr-bp-settings' ),
            'opt_key'                      => DGR_Config::OPTION_KEY,
        ];

        require __DIR__ . '/views/settings-page.php';
    }

    private static function get_last_test_connection_result() {
        $stored = get_option( self::TEST_CONNECTION_RESULT_OPTION, [] );
        if ( ! is_array( $stored ) || empty( $stored ) ) {
            return [];
        }

        return [
            'ok'      => ! empty( $stored['ok'] ),
            'code'    => isset( $stored['code'] ) ? sanitize_key( $stored['code'] ) : '',
            'http'    => isset( $stored['http'] ) ? intval( $stored['http'] ) : 0,
            'message' => isset( $stored['message'] ) ? sanitize_text_field( $stored['message'] ) : '',
            'time'    => isset( $stored['time'] ) ? sanitize_text_field( $stored['time'] ) : '',
        ];
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DGR_Admin_Notices {
    const TRANSIENT_KEY = 'dgr_bp_admin_notice';

    public static function set_notice( $type, $msg ) {
        set_transient( self::TRANSIENT_KEY, [
            'type' => $type,
            'msg'  => $msg,
        ], 60 );
    }

    public static function consume_notice() {
        $notice = get_transient( self::TRANSIENT_KEY );
        if ( is_array( $notice ) && ! empty( $notice['msg'] ) ) {
            delete_transient( self::TRANSIENT_KEY );
            return [
                'class' => ( ! empty( $notice['type'] ) && 'updated' === $notice['type'] ) ? 'updated' : 'error',
                'msg'   => $notice['msg'],
            ];
        }

        return null;
    }

    /**
     * Persistent (non-transient) status notices that the settings page
     * always shows when their condition is true. Order matters: salt
     * rotation is more actionable than the plaintext-fallback warning,
     * so it goes first.
     */
    public static function get_persistent_notices() {
        $notices = [];

        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return $notices;
        }

        if ( ! class_exists( 'DGR_Settings' ) ) {
            return $notices;
        }

        if ( DGR_Settings::is_token_decryption_failed( DGR_Config::TOKEN_KEY ) ) {
            $notices[] = [
                'class' => 'error',
                'msg'   => __( 'Stored OAuth tokens could not be decrypted (possibly after a WordPress salt rotation). Click "Remove stored tokens" and re-authorize to continue fetching reviews.', 'dynamic-google-reviews' ),
            ];
        }

        if ( DGR_Settings::is_encrypted_token_unreadable_without_libsodium( DGR_Config::TOKEN_KEY ) ) {
            $notices[] = [
                'class' => 'error',
                'msg'   => __( 'Encrypted OAuth tokens cannot be read because libsodium is unavailable on this server. Enable/install libsodium or click "Remove stored tokens" and re-authorize.', 'dynamic-google-reviews' ),
            ];
        }

        if ( DGR_Settings::is_plaintext_token_fallback_active( DGR_Config::TOKEN_KEY ) ) {
            $notices[] = [
                'class' => 'error',
                'msg'   => __( 'OAuth tokens are stored without encryption because libsodium is unavailable on this server.', 'dynamic-google-reviews' ),
            ];
        }

        return $notices;
    }
}

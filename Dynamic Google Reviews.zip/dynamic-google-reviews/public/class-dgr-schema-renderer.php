<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once dirname( __DIR__ ) . '/includes/class-dgr-config.php';
require_once dirname( __DIR__ ) . '/includes/class-dgr-settings.php';
require_once dirname( __DIR__ ) . '/includes/class-dgr-review-normalizer.php';
require_once dirname( __DIR__ ) . '/includes/class-dgr-runtime.php';

class DGR_Schema_Renderer {
    public static function register_hooks() {
        add_action( 'wp_head', [ __CLASS__, 'inject_json_ld' ] );
    }

    public static function inject_json_ld( $opt_key = null, $transient_key = null ) {
        if ( null === $opt_key ) {
            $opt_key = DGR_Config::OPTION_KEY;
        }

        if ( null === $transient_key ) {
            $transient_key = DGR_Config::TRANSIENT_KEY;
        }
        if ( is_admin() ) {
            return;
        }

        if ( DGR_Settings::use_homepage_only_json_ld_default( $opt_key ) ) {
            if ( ! is_front_page() ) {
                if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                    echo "\n<!-- DGR: JSON-LD injection skipped for this page (fresh default is homepage only) -->\n";
                }
                return;
            }
        } elseif ( ! DGR_Runtime::should_inject_on_current_page( $opt_key ) ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                echo "\n<!-- DGR: JSON-LD injection skipped for this page (not selected) -->\n";
            }
            return;
        }

        $reviews = get_transient( $transient_key );
        if ( ! is_array( $reviews ) || empty( $reviews ) ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                echo "\n<!-- DGR: no reviews available or all filtered out -->\n";
            }
            return;
        }

        $min         = DGR_Settings::get_min_rating( $opt_key, 1 );
        $max_reviews = DGR_Settings::get_max_reviews( $opt_key, 100 );

        $aggregate_reviews = DGR_Review_Normalizer::normalize_reviews( $reviews, 1, max( 1, count( $reviews ) ) );

        if ( empty( $aggregate_reviews ) ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                echo "\n<!-- DGR: reviews exist but none have a valid rating -->\n";
            }
            return;
        }

        $aggregate_sum = 0;
        foreach ( $aggregate_reviews as $r ) {
            $aggregate_sum += intval( $r['starRating'] );
        }

        $display_reviews = array_slice( array_filter( $aggregate_reviews, function ( $r ) use ( $min ) {
            return intval( $r['starRating'] ) >= $min;
        } ), 0, $max_reviews );

        $list = [];
        foreach ( $display_reviews as $r ) {
            $rating = intval( $r['starRating'] );
            $list[] = [
                '@type'         => 'Review',
                'author'        => [ '@type' => 'Person', 'name' => sanitize_text_field( $r['reviewer']['displayName'] ) ],
                'datePublished' => substr( $r['createTime'], 0, 10 ),
                'reviewBody'    => sanitize_textarea_field( $r['comment'] ),
                'reviewRating'  => [ '@type' => 'Rating', 'ratingValue' => $rating ],
            ];
        }

        $count       = count( $aggregate_reviews );
        $biz_name    = sanitize_text_field( DGR_Settings::get_business_name( $opt_key, '' ) );
        $biz_address = sanitize_textarea_field( DGR_Settings::get_address( $opt_key, '' ) );

        $schema = [
            '@context'        => 'https://schema.org',
            '@type'           => 'LocalBusiness',
            'name'            => $biz_name ? $biz_name : sanitize_text_field( get_bloginfo( 'name' ) ),
            'aggregateRating' => [
                '@type'       => 'AggregateRating',
                'ratingValue' => $count ? round( $aggregate_sum / $count, 1 ) : 0,
                'reviewCount' => $count,
            ],
            'review'          => $list,
        ];

        if ( ! empty( $biz_address ) ) {
            $schema['address'] = [
                '@type'         => 'PostalAddress',
                'streetAddress' => $biz_address,
            ];
        }

        echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once dirname( __DIR__ ) . '/includes/class-dgr-config.php';
require_once dirname( __DIR__ ) . '/includes/class-dgr-settings.php';
require_once dirname( __DIR__ ) . '/includes/class-dgr-review-normalizer.php';

class DGR_Shortcodes {
    public static function register_hooks() {
        add_shortcode( 'dgr_debug_reviews', [ __CLASS__, 'debug_reviews' ] );
    }

    public static function debug_reviews( $atts, $transient_key = null, $opt_key = null, $last_fetch_key = null ) {
        if ( null === $transient_key ) {
            $transient_key = DGR_Config::TRANSIENT_KEY;
        }

        if ( null === $opt_key ) {
            $opt_key = DGR_Config::OPTION_KEY;
        }

        if ( null === $last_fetch_key ) {
            $last_fetch_key = DGR_Config::LAST_FETCH_KEY;
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            return '';
        }

        $reviews = get_transient( $transient_key );
        $last    = DGR_Settings::get_last_fetch( $last_fetch_key, '' );
        $min     = DGR_Settings::get_min_rating( $opt_key, 1 );
        $max     = DGR_Settings::get_max_reviews( $opt_key, 100 );

        ob_start();
        echo '<div style="background:#f1f1f1;border:1px solid #ccc;padding:10px;font-family:monospace;">';
        echo '<h3>' . esc_html__( 'Dynamic Google Reviews Debug', 'dynamic-google-reviews' ) . '</h3>';
        echo '<p><strong>' . esc_html__( 'Last fetch:', 'dynamic-google-reviews' ) . '</strong> ' . esc_html( $last ?: __( 'never', 'dynamic-google-reviews' ) ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Stored reviews count:', 'dynamic-google-reviews' ) . '</strong> ' . esc_html( (string) ( is_array( $reviews ) ? count( $reviews ) : 0 ) ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Min rating threshold:', 'dynamic-google-reviews' ) . '</strong> ' . esc_html( (string) (int) $min ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Max reviews (fetch & JSON-LD):', 'dynamic-google-reviews' ) . '</strong> ' . esc_html( (string) (int) $max ) . '</p>';

        if ( is_array( $reviews ) && ! empty( $reviews ) ) {
            $slice = DGR_Review_Normalizer::normalize_reviews( $reviews, $min, $max );
            echo '<p><strong>' . sprintf( esc_html__( 'Preview (up to %d):', 'dynamic-google-reviews' ), (int) $max ) . '</strong></p>';
            echo '<pre>' . esc_html( print_r( $slice, true ) ) . '</pre>';
        } else {
            echo '<p><em>' . esc_html__( 'No reviews stored.', 'dynamic-google-reviews' ) . '</em></p>';
        }

        echo '</div>';
        return ob_get_clean();
    }
}

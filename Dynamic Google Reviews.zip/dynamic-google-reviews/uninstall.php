<?php
/**
 * Uninstall cleanup for Dynamic Google Reviews.
 *
 * Removes only this plugin's explicitly owned options, transients, and cron hook.
 *
 * @package Dynamic_Google_Reviews
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

/**
 * Delete plugin-owned persistent data for the current site.
 */
function dgr_uninstall_cleanup_site() {
    $option_keys = [
        'dgr_bp_settings',
        'dgr_bp_tokens',
        'dgr_bp_last_fetch',
        'dgr_bp_last_fetch_outcome',
        'dgr_bp_last_test_connection',
    ];

    foreach ( $option_keys as $option_key ) {
        delete_option( $option_key );
    }

    $transient_keys = [
        'dgr_bp_reviews',
        'dgr_bp_admin_notice',
        'dgr_bp_force_fetch_lock',
        'dgr_bp_test_connection_lock',
    ];

    foreach ( $transient_keys as $transient_key ) {
        delete_transient( $transient_key );
    }

    wp_clear_scheduled_hook( 'dgr_bp_fetch' );
}

if ( is_multisite() && function_exists( 'get_sites' ) && function_exists( 'switch_to_blog' ) && function_exists( 'restore_current_blog' ) ) {
    $site_ids = get_sites(
        [
            'fields' => 'ids',
        ]
    );

    foreach ( $site_ids as $site_id ) {
        switch_to_blog( $site_id );
        dgr_uninstall_cleanup_site();
        restore_current_blog();
    }
} else {
    dgr_uninstall_cleanup_site();
}

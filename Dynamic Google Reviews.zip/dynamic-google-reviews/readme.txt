=== Dynamic Google Reviews ===
Contributors: rokasgolcas
Donate link:
Tags: google, reviews, business profile, json-ld, schema, google-business
Requires at least: 5.8
Requires PHP: 8.1
Tested up to: 6.6
Stable tag: 3.3.0
License: GPLv2+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically pulls the newest Google Business Profile reviews via OAuth2, filters by minimum star rating, and injects them into the page as LocalBusiness JSON-LD for rich snippets.

== Description ==
Dynamic Google Reviews fetches the most recent reviews from your Google Business Profile (formerly Google My Business) over the official REST API using OAuth2, optionally filters them by a minimum star rating, and injects the result as `LocalBusiness` / `AggregateRating` / `Review` JSON-LD into the front of the page. It is built for SEO / rich-snippet use cases — minimal configuration, no manual markup required. Suitable for both small businesses and larger sites that need fine-grained control over which pages display the structured data.

Main features:

* Uses the Google Business Profile REST API (v4) with OAuth2 authorization.
* Self-contained OAuth2 client for OAuth requests, with bundled Composer autoloader/vendor support still required at runtime.
* OAuth tokens are encrypted at rest using libsodium (`sodium_crypto_secretbox`) keyed off your WordPress salts when libsodium is available; a sticky admin notice warns when the encryption is unavailable.
* Configurable refresh interval (daily / weekly / monthly) with the cron event automatically rescheduled when the setting changes.
* Configurable minimum review rating used for the displayed `review` list. The aggregate rating in the schema is always computed over the unfiltered set so it accurately reflects the source data.
* Configurable maximum review count for both the fetch and the JSON-LD output.
* Settings page for client ID / client secret, account ID, location ID, business name, and street address.
* Multi-page mode: include the JSON-LD only on selected pages. On a brand-new install, the JSON-LD only appears on the front page until you save settings (per Google's recommendation that `LocalBusiness` should appear on a single canonical page).
* Sticky last-fetch status panel on the settings page (success / failure, error code, message, and review count).
* "Force fetch now" and "Test connection" buttons on the settings page (POST + nonce + capability + action-specific locks: 30 seconds for force fetch, 15 seconds for test connection).
* Token removal button to drop stored OAuth tokens.
* Diagnostic shortcode `[dgr_debug_reviews]` for use on a private page (admin-only output; non-admins see nothing).
* All admin controls protected with capability checks and nonces. All input centrally sanitized through a single field registry.

== Installation ==
1. Upload the plugin directory to `wp-content/plugins/`.
2. Activate the plugin from the WordPress admin.
3. Go to *Settings → Google Reviews* and enter:
   * Client ID and Client secret (Google Cloud project; OAuth 2.0 Client credentials).
   * Account ID and Location ID (Business Profile).
   * Optionally adjust *Min rating*, *Max reviews*, *Fetch interval*, *Business name*, *Address*.
   * Optionally enable *Add to multiple pages* and pick the pages where the JSON-LD should appear.
4. Click *Get Authorization Code from Google* and complete the OAuth flow. Your tokens will be stored (encrypted, when libsodium is available).
5. Use *Test connection* to verify credentials, or *Force fetch now* to populate reviews immediately.

== Usage ==
* The JSON-LD is injected into `<head>` automatically based on your settings.
* To force a fresh fetch, use the *Force fetch now* button on the settings page (this is a POST submission protected by a nonce; old `&dgr_force_fetch=1` URL-style triggers from earlier versions are no longer accepted).
* For diagnostics, create a private (or admin-only) page and place the shortcode `[dgr_debug_reviews]` on it. The output shows the last fetch time, stored review count, configured filters, and a normalized preview.

== Frequently Asked Questions ==

= I see "OAuth tokens are stored without encryption because libsodium is unavailable on this server." =
Your PHP build does not include the libsodium extension. Tokens still work but are stored in plaintext in `wp_options`. Ask your host to enable libsodium (it is bundled with PHP 7.2+ on most modern hosts) and re-save your tokens; the next read will silently re-encrypt them.

= I see "Stored OAuth tokens could not be decrypted (possibly after a salt rotation). Please re-authorize." =
This appears when the WordPress secret keys / salts in `wp-config.php` were changed after tokens were stored. The encrypted payload can no longer be opened. Click *Remove stored tokens* and re-run the OAuth flow.

= How do I include rich data only on certain pages? =
Enable *Add to multiple pages* and pick the pages from the list. With the option disabled, the JSON-LD is injected on every page type the theme renders. On a fresh install (no settings ever saved) the plugin defaults to homepage-only injection.

= How do I remove stored Google tokens? =
Use the *Remove stored tokens* button on the settings page. After removal you must run the OAuth flow again before the plugin can fetch.

= Does filtering by minimum rating affect my AggregateRating? =
No. The `aggregateRating` block in the schema is always computed over the unfiltered review set, regardless of the *Min rating* setting. The *Min rating* only controls which individual reviews are listed in the `review` array. Note that hiding low ratings from the displayed list while keeping the unfiltered aggregate is the intended structured-data behavior; if you want the aggregate to reflect a filtered set, that may conflict with Google's review-snippet policy and is not provided.

== Security notes ==
* OAuth tokens are stored encrypted (sodium secretbox) when libsodium is available. The encryption key is derived from `wp_salt()`. Rotating your WordPress salts (recommended after a breach) will permanently invalidate the stored tokens; use *Remove stored tokens* and re-authorize.
* Admin actions (force fetch, test connection, token removal) all require `manage_options` and a valid nonce, and are POST-only.
* No custom database queries are issued; all storage goes through the WordPress options/transients API.
* Logging is disabled by default. When enabled via the `dgr_bp_enable_logging` filter, the logger redacts known token-shaped strings and sensitive keys before writing to `error_log`.

== Hooks and filters ==
* `dgr_bp_enable_logging` (filter, default `false`) — return `true` to enable the diagnostic logger.

== Changelog ==

= 3.3.0 =
* New: self-contained OAuth2 client for OAuth requests; OAuth uses WordPress HTTP APIs while the plugin still requires its bundled Composer autoloader/vendor files at runtime.
* New: encrypted-at-rest OAuth tokens via libsodium with graceful plaintext fallback and admin notice.
* New: salt-rotation detection — the settings page now shows a tailored notice when stored encrypted tokens can no longer be decrypted.
* New: configurable fetch interval (daily / weekly / monthly) with matching transient TTLs; cron is rescheduled automatically when the interval changes.
* New: sticky last-fetch outcome panel on the settings page (success/failure, error code, message, review count).
* New: *Test connection* button to validate OAuth credentials synchronously.
* New: centralized field registry (`DGR_Field_Registry`) — single source of truth for sanitization, runtime numeric rules, and admin UI metadata.
* New: extracted `DGR_Token_Storage` and `DGR_Fetch_Outcome` classes; `DGR_Settings` now delegates and is materially smaller.
* Changed: *Force fetch* is now a POST submission with a 30-second rate-limit lock; the legacy `&dgr_force_fetch=1` GET URL is no longer accepted.
* Changed: schema renderer always computes `aggregateRating` over the unfiltered review set, regardless of the *Min rating* filter.
* Changed: brand-new installs only inject JSON-LD on the front page until settings are saved.
* Changed: frontend HTML diagnostic comments are gated behind `WP_DEBUG`.
* Changed: review sort now falls back to `updateTime` when `createTime` is missing or invalid.
* Changed: removed unused v1 review-endpoint fallbacks (the Business Profile reviews API only exists on `mybusiness.googleapis.com/v4`).
* Fixed: OAuth callback handler — duplicate state-verification branches collapsed into one.
* Fixed: `[dgr_debug_reviews]` shortcode now returns an empty string for non-admins (no public footprint).
* Fixed: minor admin/UI escaping and indentation cleanups.

= 3.2.1 =
* Option to inject JSON-LD only on selected pages.
* Business name and address fields included in `LocalBusiness` schema.
* Token-removal button.
* Minor UI improvements.

= 3.x =
* Earlier versions: baseline review fetching, filtering, and JSON-LD injection.

== License ==
GNU General Public License v2 (or later). See https://www.gnu.org/licenses/gpl-2.0.html

== Author ==
Rokas Golcas — author / maintainer

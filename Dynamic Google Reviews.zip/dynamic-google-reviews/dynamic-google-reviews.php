<?php
/**
 * Plugin Name:       Dynamic Google Reviews
 * Description:       Fetches newest reviews via the Business Profile REST API with OAuth2,
 *                    filters by star threshold, and injects JSON-LD. Includes max reviews option.
 * Version:           3.3.0
 * Requires at least: 5.8
 * Requires PHP:      8.1
 * Tested up to:      6.6
 * Author:            Rokas Golcas
 * License:           GPLv2+
 * Text Domain:       dynamic-google-reviews
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'DGR_PLUGIN_FILE' ) ) {
    define( 'DGR_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'DGR_PLUGIN_DIR' ) ) {
    define( 'DGR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'DGR_VERSION' ) ) {
    define( 'DGR_VERSION', '3.3.0' );
}

require_once DGR_PLUGIN_DIR . 'includes/class-dgr-config.php';
require_once DGR_PLUGIN_DIR . 'includes/class-dgr-business-profile.php';

add_action( 'plugins_loaded', [ 'DGR_I18n', 'load_textdomain' ] );

DGR_Business_Profile::init();

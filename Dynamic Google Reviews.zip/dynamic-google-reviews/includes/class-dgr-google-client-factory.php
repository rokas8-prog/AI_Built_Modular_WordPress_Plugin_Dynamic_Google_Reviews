<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DGR_Google_Client_Factory {
    public static function build( $opts, $state = null ) {
        $client = new DGR_Google_OAuth2_Client();
        $client->setClientId( $opts['client_id'] ?? '' );
        $client->setClientSecret( $opts['client_secret'] ?? '' );
        $client->setRedirectUri( admin_url( 'options-general.php?page=dgr-bp-settings' ) );
        $client->addScope( 'https://www.googleapis.com/auth/business.manage' );

        $client->setAccessType( 'offline' );
        $client->setPrompt( 'consent' );

        if ( null !== $state ) {
            $client->setState( $state );
        }

        return $client;
    }
}

class DGR_Google_OAuth2_Client {
    const OAUTH2_AUTH_URL  = 'https://accounts.google.com/o/oauth2/v2/auth';
    const OAUTH2_TOKEN_URI = 'https://oauth2.googleapis.com/token';

    private $client_id        = '';
    private $client_secret    = '';
    private $redirect_uri     = '';
    private $requested_scopes = [];
    private $access_type      = 'offline';
    private $prompt           = null;
    private $state            = null;
    private $token            = null;

    public function setClientId( $client_id ) {
        $this->client_id = (string) $client_id;
    }

    public function setClientSecret( $client_secret ) {
        $this->client_secret = (string) $client_secret;
    }

    public function setRedirectUri( $redirect_uri ) {
        $this->redirect_uri = (string) $redirect_uri;
    }

    public function setAccessType( $access_type ) {
        $this->access_type = (string) $access_type;
    }

    public function setPrompt( $prompt ) {
        $this->prompt = (string) $prompt;
    }

    public function setState( $state ) {
        $this->state = (string) $state;
    }

    public function addScope( $scope_or_scopes ) {
        if ( is_string( $scope_or_scopes ) ) {
            if ( ! in_array( $scope_or_scopes, $this->requested_scopes, true ) ) {
                $this->requested_scopes[] = $scope_or_scopes;
            }
            return;
        }

        if ( is_array( $scope_or_scopes ) ) {
            foreach ( $scope_or_scopes as $scope ) {
                $this->addScope( $scope );
            }
        }
    }

    public function createAuthUrl() {
        // Single source of truth for query parameters. array_filter drops
        // keys whose value is null or empty string so we never emit
        // `redirect_uri=` / `state=` / `scope=` placeholders.
        $params = array_filter(
            [
                'response_type' => 'code',
                'client_id'     => $this->client_id,
                'redirect_uri'  => $this->redirect_uri,
                'access_type'   => $this->access_type,
                'prompt'        => $this->prompt,
                'state'         => $this->state,
                'scope'         => $this->prepareScopes(),
            ],
            function( $value ) {
                return null !== $value && '' !== $value;
            }
        );

        return self::OAUTH2_AUTH_URL . '?' . http_build_query( $params, '', '&', PHP_QUERY_RFC3986 );
    }

    public function fetchAccessTokenWithAuthCode( $code ) {
        if ( 0 === strlen( (string) $code ) ) {
            throw new InvalidArgumentException( 'Invalid code' );
        }

        $creds = $this->token_request( [
            'grant_type'    => 'authorization_code',
            'code'          => (string) $code,
            'redirect_uri'  => $this->redirect_uri,
            'client_id'     => $this->client_id,
            'client_secret' => $this->client_secret,
        ] );

        if ( $creds && isset( $creds['access_token'] ) ) {
            $creds['created'] = time();
            $this->setAccessToken( $creds );
        }

        return $creds;
    }

    public function fetchAccessTokenWithRefreshToken( $refresh_token = null ) {
        if ( null === $refresh_token ) {
            if ( ! isset( $this->token['refresh_token'] ) ) {
                throw new LogicException( 'refresh token must be passed in or set as part of setAccessToken' );
            }
            $refresh_token = $this->token['refresh_token'];
        }

        $creds = $this->token_request( [
            'grant_type'    => 'refresh_token',
            'refresh_token' => (string) $refresh_token,
            'client_id'     => $this->client_id,
            'client_secret' => $this->client_secret,
        ] );

        if ( $creds && isset( $creds['access_token'] ) ) {
            $creds['created'] = time();
            if ( ! isset( $creds['refresh_token'] ) ) {
                $creds['refresh_token'] = $refresh_token;
            }
            $this->setAccessToken( $creds );
        }

        return $creds;
    }

    public function setAccessToken( $token ) {
        if ( is_string( $token ) ) {
            $json  = json_decode( $token, true );
            $token = is_array( $json ) ? $json : [ 'access_token' => $token ];
        }

        if ( null === $token ) {
            throw new InvalidArgumentException( 'invalid json token' );
        }

        if ( ! isset( $token['access_token'] ) ) {
            throw new InvalidArgumentException( 'Invalid token format' );
        }

        $this->token = $token;
    }

    public function getAccessToken() {
        return $this->token;
    }

    public function isAccessTokenExpired() {
        if ( ! $this->token ) {
            return true;
        }

        $created = 0;
        if ( isset( $this->token['created'] ) ) {
            $created = $this->token['created'];
        } elseif ( isset( $this->token['id_token'] ) && 2 === substr_count( $this->token['id_token'], '.' ) ) {
            $parts   = explode( '.', $this->token['id_token'] );
            $payload = json_decode( base64_decode( $parts[1] ), true );
            if ( $payload && isset( $payload['iat'] ) ) {
                $created = $payload['iat'];
            }
        }

        if ( ! isset( $this->token['expires_in'] ) ) {
            return true;
        }

        return ( $created + ( $this->token['expires_in'] - 30 ) ) < time();
    }

    private function prepareScopes() {
        if ( empty( $this->requested_scopes ) ) {
            return null;
        }

        return implode( ' ', $this->requested_scopes );
    }

    private function token_request( $body ) {
        $version    = defined( 'DGR_VERSION' ) ? DGR_VERSION : 'dev';
        $user_agent = 'DynamicGoogleReviews/' . $version . ' (WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url( '/' ) . ')';

        $response = wp_remote_post( self::OAUTH2_TOKEN_URI, [
            'timeout'     => 20,
            'redirection' => 2,
            'headers'     => [
                'Accept'        => 'application/json',
                'Cache-Control' => 'no-store',
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body'        => $body,
            'user-agent'  => $user_agent,
        ] );

        if ( is_wp_error( $response ) ) {
            return [ 'error' => $response->get_error_message() ];
        }

        $decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( is_array( $decoded ) ) {
            return $decoded;
        }

        return [ 'error' => 'invalid_token_response' ];
    }
}

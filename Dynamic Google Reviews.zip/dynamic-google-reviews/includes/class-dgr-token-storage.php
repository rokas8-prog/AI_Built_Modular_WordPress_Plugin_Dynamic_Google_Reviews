<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * DGR_Token_Storage
 *
 * Owns OAuth token persistence: encryption at rest via libsodium when
 * available, plaintext fallback when not, transparent migration from
 * legacy plaintext rows, and detection of post-salt-rotation
 * decryption failures so the admin layer can surface a tailored notice.
 *
 * No public method on DGR_Settings was removed — DGR_Settings still
 * exposes get_tokens() / store_tokens() / has_access_token() etc. as
 * thin delegators to this class for backwards compatibility.
 */
class DGR_Token_Storage {

    const STORAGE_MARKER     = 'sodium_secretbox';
    const STORAGE_MARKER_KEY = '_dgr_storage';

    public static function get( $option_key ) {
        $stored = get_option( $option_key, [] );

        if ( ! is_array( $stored ) ) {
            return [];
        }

        if ( self::is_encrypted_payload( $stored ) ) {
            $decrypted = self::decrypt_payload( $stored );

            // Salt rotation or any other decrypt failure: return empty so
            // the rest of the codebase behaves as if no token exists, but
            // leave the unreadable payload on disk so the admin notice
            // can detect and explain the situation.
            return is_array( $decrypted ) ? $decrypted : [];
        }

        // Legacy plaintext payload: silently re-encrypt on first read
        // when libsodium is available, so the next read returns from the
        // encrypted branch above.
        if ( ! empty( $stored ) && self::can_encrypt() ) {
            self::store( $option_key, $stored );
        }

        return $stored;
    }

    public static function store( $option_key, $tokens ) {
        $tokens = is_array( $tokens ) ? $tokens : [];

        return update_option( $option_key, self::prepare_for_storage( $tokens ), false );
    }

    public static function get_value( $option_key, $field, $default = '' ) {
        $tokens = self::get( $option_key );

        return $tokens[ $field ] ?? $default;
    }

    public static function has_access_token( $option_key ) {
        return ! empty( self::get_value( $option_key, 'access_token', '' ) );
    }

    /**
     * True when libsodium is unavailable AND tokens are currently sitting
     * in the database in plaintext. Drives the "your tokens are
     * unencrypted" admin notice.
     */
    public static function is_plaintext_fallback_active( $option_key ) {
        if ( self::can_encrypt() ) {
            return false;
        }

        $stored = get_option( $option_key, [] );

        return is_array( $stored ) && ! empty( $stored ) && ! self::is_encrypted_payload( $stored );
    }

    /**
     * True when an encrypted payload is on disk but cannot be decrypted —
     * the canonical signal for "WordPress salts were rotated since the
     * tokens were stored". Distinct from "no tokens" and from "plaintext
     * tokens", so the admin layer can show a different message.
     */
    public static function is_decryption_failed( $option_key ) {
        if ( ! self::can_encrypt() ) {
            return false;
        }

        $stored = get_option( $option_key, [] );

        if ( ! is_array( $stored ) || ! self::is_encrypted_payload( $stored ) ) {
            return false;
        }

        return [] === self::decrypt_payload( $stored );
    }

    public static function is_encrypted_payload_unreadable_without_libsodium( $option_key ) {
        if ( self::can_encrypt() ) {
            return false;
        }

        $stored = get_option( $option_key, [] );

        return is_array( $stored ) && self::is_encrypted_payload( $stored );
    }

    public static function delete( $option_key ) {
        return delete_option( $option_key );
    }

    private static function prepare_for_storage( $tokens ) {
        if ( empty( $tokens ) || ! self::can_encrypt() ) {
            return $tokens;
        }

        $json = wp_json_encode( $tokens );
        if ( ! is_string( $json ) || '' === $json ) {
            return [];
        }

        $key = self::get_encryption_key();
        if ( '' === $key ) {
            return $tokens;
        }

        try {
            $nonce      = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
            $ciphertext = sodium_crypto_secretbox( $json, $nonce, $key );
        } catch ( Exception $e ) {
            return $tokens;
        }

        return [
            self::STORAGE_MARKER_KEY => self::STORAGE_MARKER,
            'nonce'                  => base64_encode( $nonce ),
            'ciphertext'             => base64_encode( $ciphertext ),
        ];
    }

    private static function decrypt_payload( $stored ) {
        if ( ! self::can_encrypt() || empty( $stored['nonce'] ) || empty( $stored['ciphertext'] ) ) {
            return [];
        }

        $key = self::get_encryption_key();
        if ( '' === $key ) {
            return [];
        }

        $nonce      = base64_decode( (string) $stored['nonce'], true );
        $ciphertext = base64_decode( (string) $stored['ciphertext'], true );
        if ( false === $nonce || false === $ciphertext ) {
            return [];
        }

        $json = sodium_crypto_secretbox_open( $ciphertext, $nonce, $key );
        if ( false === $json ) {
            return [];
        }

        $tokens = json_decode( $json, true );

        return is_array( $tokens ) ? $tokens : [];
    }

    private static function is_encrypted_payload( $stored ) {
        return is_array( $stored )
            && isset( $stored[ self::STORAGE_MARKER_KEY ] )
            && self::STORAGE_MARKER === $stored[ self::STORAGE_MARKER_KEY ];
    }

    public static function can_encrypt() {
        return function_exists( 'sodium_crypto_secretbox' )
            && function_exists( 'sodium_crypto_secretbox_open' )
            && function_exists( 'sodium_crypto_generichash' )
            && defined( 'SODIUM_CRYPTO_SECRETBOX_KEYBYTES' )
            && defined( 'SODIUM_CRYPTO_SECRETBOX_NONCEBYTES' );
    }

    private static function get_encryption_key() {
        $material = self::get_encryption_material();
        if ( '' === $material ) {
            return '';
        }

        return sodium_crypto_generichash( $material, '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES );
    }

    private static function get_encryption_material() {
        if ( function_exists( 'wp_salt' ) ) {
            return wp_salt( 'auth' ) . '|' . wp_salt( 'secure_auth' ) . '|' . wp_salt( 'logged_in' ) . '|' . wp_salt( 'nonce' );
        }

        $parts = [];
        foreach ( [ 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT' ] as $constant ) {
            if ( defined( $constant ) ) {
                $parts[] = constant( $constant );
            }
        }

        return implode( '|', array_filter( $parts, 'is_string' ) );
    }
}

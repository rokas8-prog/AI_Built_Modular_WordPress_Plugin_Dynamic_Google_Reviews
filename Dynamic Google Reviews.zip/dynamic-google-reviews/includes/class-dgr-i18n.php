<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DGR_I18n {
    public static function load_textdomain() {
        load_plugin_textdomain(
            'dynamic-google-reviews',
            false,
            dirname( plugin_basename( DGR_PLUGIN_FILE ) ) . '/languages/'
        );
    }
}

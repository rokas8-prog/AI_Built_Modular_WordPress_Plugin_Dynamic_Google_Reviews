<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/class-dgr-field-registry.php';

class DGR_Config {
    const OPTION_KEY               = 'dgr_bp_settings';
    const TOKEN_KEY                = 'dgr_bp_tokens';
    const TRANSIENT_KEY            = 'dgr_bp_reviews';
    const LAST_FETCH_KEY           = 'dgr_bp_last_fetch';
    const CRON_HOOK                = 'dgr_bp_fetch';
    const FORCE_FETCH_PARAM        = 'dgr_force_fetch';
    const FORCE_FETCH_NONCE_PARAM  = 'dgr_ff_nonce';
    const FORCE_FETCH_NONCE_ACTION = 'dgr_bp_force_fetch';
    const OAUTH_STATE_NONCE_ACTION = 'dgr_bp_oauth_state';

    public static function get_runtime_field_rules( $field = null ) {
        return DGR_Field_Registry::get_runtime_rules( $field );
    }

    public static function get_settings_sanitize_rules( $field = null ) {
        return DGR_Field_Registry::get_sanitize_rules( $field );
    }

}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/class-dgr-config.php';
require_once __DIR__ . '/class-dgr-settings.php';
require_once __DIR__ . '/class-dgr-logger.php';
require_once __DIR__ . '/class-dgr-google-client-factory.php';
require_once __DIR__ . '/class-dgr-oauth-service.php';
require_once __DIR__ . '/class-dgr-fetch-service.php';

class DGR_Runtime {
    public static function build_auth_url() {
        $result = [
            'url'   => '',
            'error' => '',
        ];

        if ( DGR_Settings::has_access_token( DGR_Config::TOKEN_KEY ) ) {
            return $result;
        }

        if ( ! DGR_OAuth_Service::ensure_autoload() ) {
            $result['error'] = __( 'Composer autoloader missing. Cannot build auth URL.', 'dynamic-google-reviews' );
            return $result;
        }

        $client = DGR_Google_Client_Factory::build(
            DGR_Settings::get_settings( DGR_Config::OPTION_KEY ),
            wp_create_nonce( DGR_Config::OAUTH_STATE_NONCE_ACTION )
        );

        if ( $client && method_exists( $client, 'createAuthUrl' ) ) {
            $result['url'] = $client->createAuthUrl();
        } else {
            $result['error'] = __( 'Cannot build auth URL: method missing on Google client.', 'dynamic-google-reviews' );
        }

        return $result;
    }

    public static function force_fetch_reviews() {
        self::fetch_reviews();
    }

    public static function fetch_reviews() {
        DGR_Logger::log( 'Starting fetch_reviews.' );

        $opts                  = DGR_Settings::get_settings( DGR_Config::OPTION_KEY );
        $credential_validation = self::validate_fetch_test_credentials( $opts );
        if ( ! $credential_validation['ok'] ) {
            $missing_key = $credential_validation['missing_key'];
            DGR_Logger::log( 'Missing required settings: ' . $missing_key );
            self::store_fetch_failure( 'missing_required_setting', sprintf( __( 'Missing required setting: %s', 'dynamic-google-reviews' ), $missing_key ) );
            return;
        }

        $tokens = DGR_Settings::get_tokens( DGR_Config::TOKEN_KEY );
        if ( ! DGR_Settings::has_access_token( DGR_Config::TOKEN_KEY ) ) {
            // Distinguish "no token at all" from unreadable stored-token states
            // so the surfaced message points the admin at the right action.
            if ( DGR_Settings::is_token_decryption_failed( DGR_Config::TOKEN_KEY ) ) {
                DGR_Logger::log( 'Stored token blob present but failed to decrypt.' );
                self::store_fetch_failure(
                    'token_decryption_failed',
                    __( 'Stored OAuth tokens could not be decrypted. Re-authorize the plugin.', 'dynamic-google-reviews' )
                );
                return;
            }
            if ( DGR_Settings::is_encrypted_token_unreadable_without_libsodium( DGR_Config::TOKEN_KEY ) ) {
                DGR_Logger::log( 'Stored encrypted token blob present but libsodium is unavailable.' );
                self::store_fetch_failure(
                    'encrypted_token_unreadable_without_libsodium',
                    __( 'Encrypted OAuth tokens cannot be read because libsodium is unavailable on this server. Enable/install libsodium or click "Remove stored tokens" and re-authorize.', 'dynamic-google-reviews' )
                );
                return;
            }
            DGR_Logger::log( 'No access token present.' );
            self::store_fetch_failure( 'missing_access_token', __( 'No access token present.', 'dynamic-google-reviews' ) );
            return;
        }

        if ( DGR_OAuth_Service::access_token_expired( $tokens ) && '' === DGR_Settings::get_token_value( DGR_Config::TOKEN_KEY, 'refresh_token', '' ) ) {
            DGR_Logger::log( 'Access token appears expired and no refresh_token available.' );
        }

        $result = DGR_Fetch_Service::fetch_reviews(
            $opts,
            $tokens,
            DGR_Config::TOKEN_KEY
        );

        if ( ! is_array( $result ) ) {
            self::store_fetch_failure( 'fetch_service_error', __( 'Fetch service did not return a result.', 'dynamic-google-reviews' ) );
            return;
        }

        if ( ! empty( $result['resolved_location_id'] ) ) {
            $opts['location_id'] = sanitize_text_field( $result['resolved_location_id'] );
            update_option( DGR_Config::OPTION_KEY, $opts );
        }

        if ( empty( $result['persist'] ) ) {
            $http = isset( $result['last_http_code'] ) ? intval( $result['last_http_code'] ) : 0;
            $err  = isset( $result['last_error'] ) ? (string) $result['last_error'] : '';
            $msg  = $err
                ? sprintf( __( 'Fetch failed (HTTP %1$d). %2$s', 'dynamic-google-reviews' ), $http, $err )
                : sprintf( __( 'Fetch failed (HTTP %d); existing stored reviews were kept.', 'dynamic-google-reviews' ), $http );
            self::store_fetch_failure( 'no_successful_response', $msg );
            return;
        }

        $reviews    = isset( $result['reviews'] ) && is_array( $result['reviews'] ) ? $result['reviews'] : [];
        $maxReviews = isset( $result['max_reviews'] ) ? max( 1, intval( $result['max_reviews'] ) ) : count( $reviews );

        set_transient( DGR_Config::TRANSIENT_KEY, $reviews, DGR_Settings::get_review_cache_ttl( DGR_Config::OPTION_KEY ) );
        update_option( DGR_Config::LAST_FETCH_KEY, current_time( 'mysql' ) );
        self::store_fetch_success( count( $reviews ) );

        DGR_Logger::log( 'Fetch completed. Stored ' . count( $reviews ) . ' reviews (limit ' . $maxReviews . ').' );
    }

    public static function test_connection() {
        $opts                  = DGR_Settings::get_settings( DGR_Config::OPTION_KEY );
        $credential_validation = self::validate_fetch_test_credentials( $opts );
        if ( ! $credential_validation['ok'] ) {
            $missing_key = $credential_validation['missing_key'];

            if ( in_array( $missing_key, [ 'client_id', 'client_secret' ], true ) ) {
                return [
                    'ok'      => false,
                    'code'    => 'missing_credentials',
                    'http'    => 0,
                    'message' => sprintf( __( 'Missing required credential: %s', 'dynamic-google-reviews' ), $missing_key ),
                ];
            }

            return [
                'ok'      => false,
                'code'    => 'missing_ids',
                'http'    => 0,
                'message' => __( 'Account ID and Location ID are required to test the connection.', 'dynamic-google-reviews' ),
            ];
        }

        if ( ! DGR_Settings::has_access_token( DGR_Config::TOKEN_KEY ) ) {
            if ( DGR_Settings::is_token_decryption_failed( DGR_Config::TOKEN_KEY ) ) {
                return [
                    'ok'      => false,
                    'code'    => 'token_decryption_failed',
                    'http'    => 0,
                    'message' => __( 'Stored OAuth tokens could not be decrypted. Remove tokens and re-authorize.', 'dynamic-google-reviews' ),
                ];
            }
            if ( DGR_Settings::is_encrypted_token_unreadable_without_libsodium( DGR_Config::TOKEN_KEY ) ) {
                return [
                    'ok'      => false,
                    'code'    => 'encrypted_token_unreadable_without_libsodium',
                    'http'    => 0,
                    'message' => __( 'Encrypted OAuth tokens cannot be read because libsodium is unavailable on this server. Enable/install libsodium or click "Remove stored tokens" and re-authorize.', 'dynamic-google-reviews' ),
                ];
            }
            return [
                'ok'      => false,
                'code'    => 'no_access_token',
                'http'    => 0,
                'message' => __( 'Authorize the plugin with Google before running a connection test.', 'dynamic-google-reviews' ),
            ];
        }

        $tokens = DGR_Settings::get_tokens( DGR_Config::TOKEN_KEY );

        return DGR_Fetch_Service::test_connection( $opts, $tokens, DGR_Config::TOKEN_KEY );
    }

    private static function store_fetch_success( $review_count ) {
        DGR_Settings::store_last_fetch_outcome(
            'success',
            'stored_reviews',
            sprintf( __( 'Stored %d review(s).', 'dynamic-google-reviews' ), max( 0, intval( $review_count ) ) ),
            [ 'review_count' => $review_count ]
        );
    }

    private static function store_fetch_failure( $code, $message ) {
        DGR_Settings::store_last_fetch_outcome( 'failure', $code, $message );
    }

    private static function validate_fetch_test_credentials( $opts ) {
        foreach ( [ 'client_id', 'client_secret', 'account_id', 'location_id' ] as $key ) {
            if ( empty( $opts[ $key ] ) ) {
                return [
                    'ok'          => false,
                    'missing_key' => $key,
                ];
            }
        }

        return [
            'ok'          => true,
            'missing_key' => '',
        ];
    }

    public static function exchange_auth_code( $code ) {
        return DGR_OAuth_Service::exchange_auth_code(
            DGR_Settings::get_settings( DGR_Config::OPTION_KEY ),
            $code,
            DGR_Settings::get_tokens( DGR_Config::TOKEN_KEY )
        );
    }

    public static function handle_oauth_callback() {
        if ( ! ( is_admin() && DGR_Settings::has_request_param( 'get', 'page' ) && DGR_Settings::has_request_param( 'get', 'code' ) && 'dgr-bp-settings' === DGR_Settings::get_request_text( 'get', 'page' ) ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $state = DGR_Settings::has_request_param( 'get', 'state' ) ? DGR_Settings::get_request_text( 'get', 'state' ) : '';
        if ( '' === $state || ! wp_verify_nonce( $state, DGR_Config::OAUTH_STATE_NONCE_ACTION ) ) {
            DGR_Admin_Notices::set_notice( 'error', __( 'Failed to verify request.', 'dynamic-google-reviews' ) );

            DGR_Logger::log( 'OAuth state verification failed.' );
            wp_safe_redirect( admin_url( 'options-general.php?page=dgr-bp-settings' ) );
            exit;
        }

        if ( ! DGR_OAuth_Service::ensure_autoload() ) {
            DGR_Admin_Notices::set_notice( 'error', __( 'Cannot complete OAuth: autoloader missing.', 'dynamic-google-reviews' ) );

            wp_safe_redirect( admin_url( 'options-general.php?page=dgr-bp-settings' ) );
            exit;
        }

        $code  = DGR_Settings::get_request_text( 'get', 'code' );
        $token = self::exchange_auth_code( $code );

        if ( isset( $token['access_token'] ) ) {
            DGR_Settings::store_tokens( DGR_Config::TOKEN_KEY, $token );
            DGR_Admin_Notices::set_notice( 'updated', __( 'Google OAuth successful! Tokens stored.', 'dynamic-google-reviews' ) );
        } else {
            DGR_Admin_Notices::set_notice( 'error', __( 'Failed to get tokens from Google.', 'dynamic-google-reviews' ) );

            DGR_Logger::log_context( 'OAuth: failed to obtain access_token.', [ 'response' => $token ] );
        }

        wp_safe_redirect( admin_url( 'options-general.php?page=dgr-bp-settings' ) );
        exit;
    }

    public static function should_inject_on_current_page( $option_key = null ) {
        if ( null === $option_key ) {
            $option_key = DGR_Config::OPTION_KEY;
        }

        if ( ! DGR_Settings::use_add_to_multiple( $option_key ) ) {
            return true;
        }

        $selected   = DGR_Settings::get_selected_pages( $option_key );
        $current_id = intval( get_queried_object_id() );
        if ( $current_id <= 0 ) {
            if ( is_front_page() ) {
                $current_id = intval( get_option( 'page_on_front' ) );
            } elseif ( is_home() ) {
                $current_id = intval( get_option( 'page_for_posts' ) );
            }
        }

        return $current_id > 0 && in_array( $current_id, $selected, true );
    }
}

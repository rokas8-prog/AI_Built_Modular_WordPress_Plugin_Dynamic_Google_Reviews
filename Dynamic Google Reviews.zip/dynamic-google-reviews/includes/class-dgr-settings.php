<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/class-dgr-token-storage.php';
require_once __DIR__ . '/class-dgr-fetch-outcome.php';

class DGR_Settings {

    /* ----------------------------------------------------------------------
     * Request helpers
     * ------------------------------------------------------------------- */

    private static function get_request_source( $method ) {
        return 'post' === strtolower( (string) $method ) ? $_POST : $_GET;
    }

    public static function has_request_param( $method, $key ) {
        $source = self::get_request_source( $method );

        return isset( $source[ $key ] );
    }

    public static function get_request_text( $method, $key, $default = '' ) {
        if ( ! self::has_request_param( $method, $key ) ) {
            return $default;
        }

        $source = self::get_request_source( $method );

        return sanitize_text_field( wp_unslash( $source[ $key ] ) );
    }

    /* ----------------------------------------------------------------------
     * Settings option (dgr_bp_settings) read/normalize
     * ------------------------------------------------------------------- */

    public static function get_settings( $option_key ) {
        $settings = get_option( $option_key, [] );

        if ( ! is_array( $settings ) ) {
            return [];
        }

        if ( DGR_Config::OPTION_KEY !== $option_key ) {
            return $settings;
        }

        return self::sanitize_settings_on_read( $settings );
    }

    public static function use_homepage_only_json_ld_default( $option_key ) {
        if ( DGR_Config::OPTION_KEY !== $option_key ) {
            return false;
        }

        return self::settings_option_missing( $option_key );
    }

    public static function settings_option_missing( $option_key ) {
        $missing = '__dgr_missing_settings_option__';

        return $missing === get_option( $option_key, $missing );
    }

    public static function get_setting( $option_key, $field, $default = '' ) {
        $settings = self::get_settings( $option_key );

        return $settings[ $field ] ?? $default;
    }

    private static function sanitize_settings_on_read( $settings ) {
        return self::normalize_settings_values( $settings, DGR_Field_Registry::get_sanitize_rules(), 'read' );
    }

    public static function normalize_settings_values( $values, $rules_by_field, $context = 'read' ) {
        $values     = is_array( $values ) ? $values : [];
        $normalized = 'read' === $context ? $values : [];

        foreach ( $rules_by_field as $field => $rules ) {
            if ( empty( $rules['stored'] ) ) {
                continue;
            }

            $default              = array_key_exists( 'default', $rules ) ? $rules['default'] : '';
            $value                = array_key_exists( $field, $values ) ? $values[ $field ] : $default;
            $normalized[ $field ] = self::normalize_setting_value( $value, $rules, $default, $context );
        }

        return $normalized;
    }

    public static function normalize_setting_value( $value, $rules, $default = '', $context = 'read' ) {
        switch ( $rules['type'] ?? '' ) {
            case 'text':
                if ( 'read' === $context && ! is_scalar( $value ) ) {
                    return $default;
                }

                return sanitize_text_field( $value );

            case 'textarea':
                if ( 'read' === $context && ! is_scalar( $value ) ) {
                    return $default;
                }

                return sanitize_textarea_field( $value );

            case 'integer':
                $value = 'read' === $context && ! is_scalar( $value ) ? (int) $default : intval( $value );

                if ( isset( $rules['min'] ) ) {
                    $value = max( (int) $rules['min'], $value );
                }

                if ( isset( $rules['max'] ) ) {
                    $value = min( (int) $rules['max'], $value );
                }

                return $value;

            case 'checkbox':
                return ! empty( $value ) ? 1 : 0;

            case 'fetch_interval':
                return self::normalize_choice_setting_value( $value, $rules, $default, $context );

            case 'array':
                return self::normalize_array_setting_value( $value, $rules, $default, $context );
        }

        return $value;
    }

    private static function normalize_choice_setting_value( $value, $rules, $default, $context ) {
        if ( 'read' === $context && ! is_scalar( $value ) ) {
            return self::normalize_choice_default( $default, $rules );
        }

        $value   = sanitize_key( $value );
        $allowed = self::get_allowed_setting_values( $rules );

        return in_array( $value, $allowed, true ) ? $value : self::normalize_choice_default( $default, $rules );
    }

    private static function normalize_choice_default( $default, $rules ) {
        $default          = sanitize_key( $default );
        $registry_default = isset( $rules['default'] ) ? sanitize_key( $rules['default'] ) : '';
        $allowed          = self::get_allowed_setting_values( $rules );

        if ( in_array( $default, $allowed, true ) ) {
            return $default;
        }

        if ( in_array( $registry_default, $allowed, true ) ) {
            return $registry_default;
        }

        return reset( $allowed ) ?: '';
    }

    private static function get_allowed_setting_values( $rules ) {
        if ( empty( $rules['allowed_values'] ) || ! is_array( $rules['allowed_values'] ) ) {
            return [];
        }

        return array_values( array_filter( array_map( 'sanitize_key', $rules['allowed_values'] ) ) );
    }

    private static function normalize_array_setting_value( $value, $rules, $default, $context ) {
        if ( ! is_array( $value ) ) {
            return 'read' === $context && is_array( $default ) ? $default : [];
        }

        if ( isset( $rules['items'] ) && 'positive_integer' === $rules['items'] ) {
            return array_values(
                array_filter(
                    array_map( 'intval', $value ),
                    function( $id ) {
                        return $id > 0;
                    }
                )
            );
        }

        return 'read' === $context && is_array( $default ) ? $default : [];
    }

    /* ----------------------------------------------------------------------
     * Fetch interval (delegates to DGR_Field_Registry's fetch_interval entry)
     * ------------------------------------------------------------------- */

    public static function normalize_fetch_interval( $value, $default = null ) {
        $rules    = DGR_Field_Registry::get_sanitize_rules( 'fetch_interval' );
        $fallback = null === $default ? ( $rules['default'] ?? '' ) : $default;

        return self::normalize_choice_setting_value( $value, $rules, $fallback, 'write' );
    }

    public static function get_fetch_interval( $option_key, $default = null ) {
        if ( DGR_Config::OPTION_KEY !== $option_key ) {
            return self::normalize_fetch_interval( $default );
        }

        if ( self::settings_option_missing( $option_key ) ) {
            return self::get_fetch_interval_fresh_default();
        }

        $settings = get_option( $option_key, [] );
        if ( ! is_array( $settings ) || ! array_key_exists( 'fetch_interval', $settings ) ) {
            return self::normalize_fetch_interval( $default );
        }

        return self::normalize_fetch_interval( $settings['fetch_interval'], $default );
    }

    private static function get_fetch_interval_fresh_default() {
        $definition = DGR_Field_Registry::get( 'fetch_interval' );
        $default    = array_key_exists( 'fresh_default', $definition ) ? $definition['fresh_default'] : ( $definition['default'] ?? null );

        return self::normalize_fetch_interval( $default );
    }

    public static function get_review_cache_ttl( $option_key ) {
        $interval   = self::get_fetch_interval( $option_key );
        $definition = DGR_Field_Registry::get( 'fetch_interval' );
        $cache_ttl  = isset( $definition['cache_ttl'] ) && is_array( $definition['cache_ttl'] ) ? $definition['cache_ttl'] : [];
        $default    = self::normalize_fetch_interval( $definition['default'] ?? null );

        if ( isset( $cache_ttl[ $interval ] ) ) {
            return (int) $cache_ttl[ $interval ];
        }

        return isset( $cache_ttl[ $default ] ) ? (int) $cache_ttl[ $default ] : 0;
    }

    /* ----------------------------------------------------------------------
     * Token storage — wrappers over DGR_Token_Storage
     * ------------------------------------------------------------------- */

    public static function get_tokens( $option_key ) {
        return DGR_Token_Storage::get( $option_key );
    }

    public static function store_tokens( $option_key, $tokens ) {
        return DGR_Token_Storage::store( $option_key, $tokens );
    }

    public static function get_token_value( $option_key, $field, $default = '' ) {
        return DGR_Token_Storage::get_value( $option_key, $field, $default );
    }

    public static function has_access_token( $option_key ) {
        return DGR_Token_Storage::has_access_token( $option_key );
    }

    public static function is_plaintext_token_fallback_active( $option_key ) {
        return DGR_Token_Storage::is_plaintext_fallback_active( $option_key );
    }

    public static function is_token_decryption_failed( $option_key ) {
        return DGR_Token_Storage::is_decryption_failed( $option_key );
    }

    public static function is_encrypted_token_unreadable_without_libsodium( $option_key ) {
        return DGR_Token_Storage::is_encrypted_payload_unreadable_without_libsodium( $option_key );
    }

    /* ----------------------------------------------------------------------
     * Last fetch — option storage (cron timestamp) and outcome wrapper
     * ------------------------------------------------------------------- */

    public static function get_last_fetch( $option_key, $default = '' ) {
        $value = get_option( $option_key );

        return false === $value ? $default : $value;
    }

    public static function get_last_fetch_outcome_option_key() {
        return DGR_Fetch_Outcome::get_option_key();
    }

    public static function store_last_fetch_outcome( $status, $code = '', $message = '', $extra = [] ) {
        return DGR_Fetch_Outcome::store( $status, $code, $message, $extra );
    }

    public static function get_last_fetch_outcome() {
        return DGR_Fetch_Outcome::get();
    }

    /* ----------------------------------------------------------------------
     * Field-specific getters used by the admin schema
     * ------------------------------------------------------------------- */

    public static function get_business_name( $option_key, $default = '' ) {
        return self::get_setting( $option_key, 'business_name', $default );
    }

    public static function get_address( $option_key, $default = '' ) {
        return self::get_setting( $option_key, 'address', $default );
    }

    private static function get_runtime_numeric_rule( $field, $key, $fallback = null ) {
        $rules = DGR_Field_Registry::get_runtime_rules( $field );

        return array_key_exists( $key, $rules ) ? $rules[ $key ] : $fallback;
    }

    private static function get_clamped_integer_setting( $option_key, $field, $default ) {
        $value = intval( self::get_setting( $option_key, $field, $default ) );
        $min   = self::get_runtime_numeric_rule( $field, 'min', null );
        $max   = self::get_runtime_numeric_rule( $field, 'max', null );

        if ( null !== $min ) {
            $value = max( (int) $min, $value );
        }

        if ( null !== $max ) {
            $value = min( (int) $max, $value );
        }

        return $value;
    }

    public static function get_min_rating( $option_key, $default = 1 ) {
        if ( 1 === func_num_args() ) {
            $default = self::get_runtime_numeric_rule( 'min_rating', 'default', $default );
        }

        return self::get_clamped_integer_setting( $option_key, 'min_rating', $default );
    }

    public static function get_max_reviews( $option_key, $default = 100 ) {
        if ( 1 === func_num_args() ) {
            $default = self::get_runtime_numeric_rule( 'max_reviews', 'default', $default );
        }

        return self::get_clamped_integer_setting( $option_key, 'max_reviews', $default );
    }

    public static function get_selected_pages( $option_key ) {
        $selected = self::get_setting( $option_key, 'selected_pages', [] );

        if ( ! is_array( $selected ) ) {
            return [];
        }

        return array_values(
            array_filter(
                array_map( 'intval', $selected ),
                function( $id ) {
                    return $id > 0;
                }
            )
        );
    }

    public static function use_add_to_multiple( $option_key ) {
        return ! empty( self::get_setting( $option_key, 'add_to_multiple', 0 ) );
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * DGR_Fetch_Outcome
 *
 * Sticky last-fetch outcome storage. Persists status/code/message/time
 * in a dedicated option (separate from the actual reviews transient) so
 * the admin settings page can render a notice that survives page
 * reloads, regardless of whether the WP transient layer evicted the
 * 60-second admin notice.
 */
class DGR_Fetch_Outcome {

    const OPTION_KEY = 'dgr_bp_last_fetch_outcome';

    public static function get_option_key() {
        return self::OPTION_KEY;
    }

    public static function store( $status, $code = '', $message = '', $extra = [] ) {
        $status = 'success' === $status ? 'success' : 'failure';
        $data   = [
            'status'  => $status,
            'code'    => sanitize_key( $code ),
            'message' => sanitize_text_field( $message ),
            'time'    => current_time( 'mysql' ),
        ];

        if ( isset( $extra['review_count'] ) ) {
            $data['review_count'] = max( 0, intval( $extra['review_count'] ) );
        }

        return update_option( self::OPTION_KEY, $data, false );
    }

    public static function get() {
        $outcome = get_option( self::OPTION_KEY, [] );

        if ( ! is_array( $outcome ) || empty( $outcome['status'] ) ) {
            return [];
        }

        $status = 'success' === $outcome['status'] ? 'success' : 'failure';
        $data   = [
            'status'  => $status,
            'code'    => isset( $outcome['code'] ) ? sanitize_key( $outcome['code'] ) : '',
            'message' => isset( $outcome['message'] ) ? sanitize_text_field( $outcome['message'] ) : '',
            'time'    => isset( $outcome['time'] ) ? sanitize_text_field( $outcome['time'] ) : '',
        ];

        if ( isset( $outcome['review_count'] ) ) {
            $data['review_count'] = max( 0, intval( $outcome['review_count'] ) );
        }

        return $data;
    }
}

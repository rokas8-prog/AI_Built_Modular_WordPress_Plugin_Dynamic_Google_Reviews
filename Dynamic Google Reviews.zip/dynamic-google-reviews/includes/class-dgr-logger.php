<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DGR_Logger {
    const REDACTED = '[redacted]';

    public static function log( $msg ) {
        if ( ! self::is_enabled() ) {
            return;
        }

        if ( is_scalar( $msg ) || null === $msg ) {
            $message = self::scrub_string( (string) $msg );
        } else {
            $message = self::encode_context( self::scrub( $msg ) );
        }

        error_log( 'DGR: ' . $message );
    }

    public static function log_context( $msg, $context = [] ) {
        if ( ! self::is_enabled() ) {
            return;
        }

        $message = self::scrub_string( (string) $msg );
        $context = self::scrub( $context );

        if ( ! empty( $context ) ) {
            $message .= ' Context: ' . self::encode_context( $context );
        }

        error_log( 'DGR: ' . $message );
    }

    public static function scrub( $value, $depth = 0 ) {
        if ( $depth > 8 ) {
            return '[max-depth]';
        }

        if ( is_array( $value ) ) {
            $scrubbed = [];

            foreach ( $value as $key => $item ) {
                if ( self::is_sensitive_key( $key ) ) {
                    $scrubbed[ $key ] = self::REDACTED;
                    continue;
                }

                $scrubbed[ $key ] = self::scrub( $item, $depth + 1 );
            }

            return $scrubbed;
        }

        if ( is_object( $value ) ) {
            if ( method_exists( $value, '__toString' ) ) {
                return self::scrub_string( (string) $value );
            }

            return '[object ' . get_class( $value ) . ']';
        }

        if ( is_string( $value ) ) {
            return self::scrub_string( $value );
        }

        return $value;
    }

    private static function is_enabled() {
        return (bool) apply_filters( 'dgr_bp_enable_logging', false );
    }

    private static function is_sensitive_key( $key ) {
        $key = strtolower( (string) $key );
        $key = str_replace( [ '-', ' ' ], '_', $key );

        if ( in_array( $key, [ 'access_token', 'refresh_token', 'client_secret', 'id_token', 'authorization', 'auth_header', 'bearer', 'code' ], true ) ) {
            return true;
        }

        if ( false !== strpos( $key, 'authorization' ) || false !== strpos( $key, 'client_secret' ) ) {
            return true;
        }

        if ( preg_match( '/(^|_)(access|refresh|id)?_?token($|_)/', $key ) ) {
            return true;
        }

        return false;
    }

    private static function scrub_string( $value ) {
        $value = preg_replace( '/\bBearer\s+[A-Za-z0-9._~+\/=-]+/i', 'Bearer ' . self::REDACTED, $value );
        $value = preg_replace( '/(\bAuthorization\s*[:=]\s*)[^\s,;]+/i', '$1' . self::REDACTED, $value );
        $value = preg_replace( '/([?&](?:access_token|refresh_token|client_secret|id_token|code|token)=)[^&\s]+/i', '$1' . self::REDACTED, $value );
        $value = preg_replace( '/((?:access_token|refresh_token|client_secret|id_token|authorization)\s*[:=]\s*)[^\s&,;]+/i', '$1' . self::REDACTED, $value );
        $value = preg_replace( '/\bya29\.[A-Za-z0-9._-]+\b/i', self::REDACTED, $value );
        $value = preg_replace( '/\b[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/', self::REDACTED, $value );

        if ( preg_match( '/^[A-Za-z0-9._~+\/=-]{32,}$/', $value ) && preg_match( '/[A-Za-z]/', $value ) && preg_match( '/[0-9]/', $value ) ) {
            return self::REDACTED;
        }

        return $value;
    }

    private static function encode_context( $context ) {
        if ( function_exists( 'wp_json_encode' ) ) {
            return (string) wp_json_encode( $context );
        }

        return (string) json_encode( $context );
    }
}

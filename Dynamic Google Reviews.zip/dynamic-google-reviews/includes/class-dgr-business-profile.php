<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/class-dgr-config.php';
require_once __DIR__ . '/class-dgr-logger.php';
require_once __DIR__ . '/class-dgr-google-client-factory.php';
require_once __DIR__ . '/class-dgr-review-normalizer.php';
require_once __DIR__ . '/class-dgr-token-storage.php';
require_once __DIR__ . '/class-dgr-fetch-outcome.php';
require_once __DIR__ . '/class-dgr-settings.php';
require_once __DIR__ . '/class-dgr-i18n.php';
require_once __DIR__ . '/class-dgr-oauth-service.php';
require_once __DIR__ . '/class-dgr-fetch-service.php';
require_once __DIR__ . '/class-dgr-runtime.php';
require_once dirname( __DIR__ ) . '/public/class-dgr-schema-renderer.php';
require_once dirname( __DIR__ ) . '/public/class-dgr-shortcodes.php';

if ( is_admin() ) {
    require_once dirname( __DIR__ ) . '/admin/class-dgr-admin-notices.php';
    require_once dirname( __DIR__ ) . '/admin/class-dgr-admin-controller.php';
    require_once dirname( __DIR__ ) . '/admin/class-dgr-admin-settings.php';
    require_once dirname( __DIR__ ) . '/admin/class-dgr-admin-fields.php';
}

class DGR_Business_Profile {
    /** --------------------------------------------------------------------
     * WP bootstrap
     * ------------------------------------------------------------------ */
    public static function init() {
        register_activation_hook( DGR_PLUGIN_FILE, [ __CLASS__, 'activate' ] );
        register_deactivation_hook( DGR_PLUGIN_FILE, [ __CLASS__, 'deactivate' ] );
        add_filter( 'cron_schedules', [ __CLASS__, 'add_monthly' ] );
        add_action( DGR_Config::CRON_HOOK, [ __CLASS__, 'fetch_reviews' ] );
        add_action( 'admin_init', [ __CLASS__, 'handle_oauth_callback' ] );

        if ( is_admin() ) {
            DGR_Admin_Controller::register_hooks();
            DGR_Admin_Settings::register_hooks();
        }

        DGR_Schema_Renderer::register_hooks();
        DGR_Shortcodes::register_hooks();
    }

    public static function activate() {
        if ( ! wp_next_scheduled( DGR_Config::CRON_HOOK ) ) {
            wp_schedule_event( time(), DGR_Settings::get_fetch_interval( DGR_Config::OPTION_KEY ), DGR_Config::CRON_HOOK );
        }

        if ( DGR_Settings::has_access_token( DGR_Config::TOKEN_KEY ) ) {
            self::fetch_reviews();
        }
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( DGR_Config::CRON_HOOK );
    }

    public static function add_monthly( $schedules ) {
        if ( ! isset( $schedules['weekly'] ) ) {
            $schedules['weekly'] = [
                'interval' => WEEK_IN_SECONDS,
                'display'  => __( 'Once Weekly', 'dynamic-google-reviews' ),
            ];
        }

        if ( ! isset( $schedules['monthly'] ) ) {
            $schedules['monthly'] = [
                'interval' => 30 * DAY_IN_SECONDS,
                'display'  => __( 'Every 30 Days', 'dynamic-google-reviews' ),
            ];
        }

        return $schedules;
    }

    public static function reschedule_fetch_event( $interval = null ) {
        $interval = null === $interval ? DGR_Settings::get_fetch_interval( DGR_Config::OPTION_KEY ) : DGR_Settings::normalize_fetch_interval( $interval, 'monthly' );

        wp_clear_scheduled_hook( DGR_Config::CRON_HOOK );
        wp_schedule_event( time(), $interval, DGR_Config::CRON_HOOK );
    }

    /** --------------------------------------------------------------------
     * Fetch reviews (with max reviews setting)
     * ------------------------------------------------------------------ */
    public static function fetch_reviews() {
        DGR_Runtime::fetch_reviews();
    }

    /** --------------------------------------------------------------------
     * OAuth callback handler
     * ------------------------------------------------------------------ */
    public static function handle_oauth_callback() {
        DGR_Runtime::handle_oauth_callback();
    }
}

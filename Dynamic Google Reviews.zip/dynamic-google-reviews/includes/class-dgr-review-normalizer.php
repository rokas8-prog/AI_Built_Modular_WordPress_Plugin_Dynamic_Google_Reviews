<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DGR_Review_Normalizer {
    public static function normalize_reviews( $reviews, $min_rating = 1, $max_reviews = 100 ) {
        if ( ! is_array( $reviews ) || empty( $reviews ) ) {
            return [];
        }

        $min_rating = intval( $min_rating );
        $max_reviews = max( 1, intval( $max_reviews ) );

        $normalized = [];
        foreach ( $reviews as $r ) {
            $rating_raw = $r['starRating'] ?? ( $r['reviewRating']['ratingValue'] ?? 0 );
            $rating     = self::map_star_rating( $rating_raw );
            if ( $rating < $min_rating ) {
                continue;
            }

            $create_time = $r['createTime'] ?? '';
            $update_time = $r['updateTime'] ?? '';

            $normalized[] = [
                'createTime'    => $create_time,
                'starRating'    => $rating,
                'comment'       => $r['comment'] ?? ( $r['reviewBody'] ?? '' ),
                'reviewer'      => [ 'displayName' => $r['reviewer']['displayName'] ?? '' ],
                '_dgr_sortTime' => self::get_sort_timestamp( $create_time, $update_time ),
            ];
        }

        usort( $normalized, function ( $a, $b ) {
            return $b['_dgr_sortTime'] <=> $a['_dgr_sortTime'];
        } );

        foreach ( $normalized as &$review ) {
            unset( $review['_dgr_sortTime'] );
        }
        unset( $review );

        return array_slice( $normalized, 0, $max_reviews );
    }

    private static function get_sort_timestamp( $create_time, $update_time ) {
        $create_timestamp = strtotime( (string) $create_time );
        if ( false !== $create_timestamp ) {
            return $create_timestamp;
        }

        $update_timestamp = strtotime( (string) $update_time );
        if ( false !== $update_timestamp ) {
            return $update_timestamp;
        }

        return 0;
    }

    private static function map_star_rating( $raw ) {
        if ( is_numeric( $raw ) ) {
            return intval( $raw );
        }
        $map = [
            'ONE'   => 1,
            'TWO'   => 2,
            'THREE' => 3,
            'FOUR'  => 4,
            'FIVE'  => 5,
        ];
        $upper = strtoupper( (string) $raw );
        return $map[ $upper ] ?? 0;
    }
}

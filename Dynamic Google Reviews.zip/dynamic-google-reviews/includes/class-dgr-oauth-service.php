<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/class-dgr-logger.php';
require_once __DIR__ . '/class-dgr-settings.php';
require_once __DIR__ . '/class-dgr-google-client-factory.php';

class DGR_OAuth_Service {

    public static function ensure_autoload() {
        $autoload = DGR_PLUGIN_DIR . 'vendor/autoload.php';
        if ( ! file_exists( $autoload ) ) {
            DGR_Logger::log( 'Composer autoload.php not found; cannot create Google_Client.' );
            return false;
        }

        try {
            require_once $autoload;
        } catch ( Throwable $e ) {
            DGR_Logger::log( 'Exception including autoload.php: ' . $e->getMessage() );
            return false;
        }

        return true;
    }

    public static function access_token_expired( $tokens ) {
        if ( empty( $tokens['access_token'] ) ) {
            return true;
        }

        if ( isset( $tokens['created'], $tokens['expires_in'] ) ) {
            $expiry = intval( $tokens['created'] ) + intval( $tokens['expires_in'] ) - 60;
            return ( time() >= $expiry );
        }

        return false;
    }

    public static function refresh_access_token( $client, &$tokens, $token_key ) {
        if ( empty( $tokens['refresh_token'] ) ) {
            return false;
        }
        if ( ! is_object( $client ) || ! method_exists( $client, 'fetchAccessTokenWithRefreshToken' ) ) {
            return false;
        }

        try {
            $refreshed = $client->fetchAccessTokenWithRefreshToken( $tokens['refresh_token'] );
        } catch ( Exception $e ) {
            DGR_Logger::log( 'Exception refreshing access token: ' . $e->getMessage() );
            return false;
        }

        if ( ! is_array( $refreshed ) || empty( $refreshed['access_token'] ) ) {
            DGR_Logger::log_context( 'Failed to refresh access token.', [ 'response' => $refreshed ] );
            return false;
        }

        $new_tokens = method_exists( $client, 'getAccessToken' ) ? $client->getAccessToken() : $refreshed;

        if ( ! is_array( $new_tokens ) ) {
            $new_tokens = $refreshed;
        }

        if ( empty( $new_tokens['refresh_token'] ) ) {
            $new_tokens['refresh_token'] = $tokens['refresh_token'];
        }

        if ( empty( $new_tokens['created'] ) ) {
            $new_tokens['created'] = time();
        }

        DGR_Settings::store_tokens( $token_key, $new_tokens );
        $tokens = $new_tokens;
        return true;
    }

    public static function create_google_client( $opts, &$tokens, $token_key ) {
        $client = DGR_Google_Client_Factory::build( $opts );
        if ( ! $client ) {
            return null;
        }

        // setAccessToken throws InvalidArgumentException on malformed input;
        // log + bail rather than fatal a cron run.
        if ( ! empty( $tokens ) && is_array( $tokens ) && ! empty( $tokens['access_token'] ) ) {
            try {
                $client->setAccessToken( $tokens );
            } catch ( Exception $e ) {
                DGR_Logger::log( 'setAccessToken rejected stored token: ' . $e->getMessage() );
                return null;
            }
        }

        $expired = false;
        if ( method_exists( $client, 'isAccessTokenExpired' ) ) {
            try {
                $expired = (bool) $client->isAccessTokenExpired();
            } catch ( Exception $e ) {
                $expired = self::access_token_expired( $tokens );
            }
        } else {
            $expired = self::access_token_expired( $tokens );
        }

        if ( $expired ) {
            DGR_Logger::log( 'Access token expired, attempting refresh if refresh_token present.' );
            self::refresh_access_token( $client, $tokens, $token_key );
            if ( ! empty( $tokens['access_token'] ) ) {
                try {
                    $client->setAccessToken( $tokens );
                } catch ( Exception $e ) {
                    DGR_Logger::log( 'setAccessToken after refresh rejected token: ' . $e->getMessage() );
                    return null;
                }
            }
        }

        return $client;
    }

    public static function exchange_auth_code( $opts, $code, $existing_tokens = [] ) {
        $client = DGR_Google_Client_Factory::build( $opts );
        if ( ! $client ) {
            return [];
        }

        try {
            $token = method_exists( $client, 'fetchAccessTokenWithAuthCode' )
                ? $client->fetchAccessTokenWithAuthCode( $code )
                : [];
        } catch ( Exception $e ) {
            DGR_Logger::log( 'fetchAccessTokenWithAuthCode threw: ' . $e->getMessage() );
            return [];
        }

        if ( isset( $token['access_token'] ) ) {
            if ( empty( $token['refresh_token'] ) && ! empty( $existing_tokens['refresh_token'] ) ) {
                $token['refresh_token'] = $existing_tokens['refresh_token'];
            }
            if ( empty( $token['created'] ) ) {
                $token['created'] = time();
            }
        }

        return $token;
    }
}

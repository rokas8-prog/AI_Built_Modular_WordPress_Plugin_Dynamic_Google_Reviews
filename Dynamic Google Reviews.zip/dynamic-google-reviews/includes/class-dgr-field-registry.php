<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * DGR_Field_Registry
 *
 * Single source of truth for the plugin's settings fields. Owns:
 *   - the per-field UI metadata used by the admin schema/renderer,
 *   - the runtime numeric rules (min/max/default) used to clamp values,
 *   - the sanitize-rule generation used by both write-time and read-time
 *     normalization,
 *   - the `cache_ttl` map for the fetch_interval field.
 *
 * Adding a new field means editing exactly one method (`all()`); other
 * helpers in this class derive from it.
 *
 * Internal-only keys that should NOT leak into the admin schema output
 * are listed in {@see internal_keys()}.
 */
class DGR_Field_Registry {

    public static function all() {
        return [
            'client_id' => [
                'type'               => 'text',
                'field'              => 'client_id',
                'default'            => '',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 10,
                'class'              => 'regular-text',
                'title'              => __( 'Client id', 'dynamic-google-reviews' ),
            ],
            'client_secret' => [
                'type'               => 'text',
                'field'              => 'client_secret',
                'default'            => '',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 20,
                'class'              => 'regular-text',
                'title'              => __( 'Client secret', 'dynamic-google-reviews' ),
            ],
            'account_id' => [
                'type'               => 'text',
                'field'              => 'account_id',
                'default'            => '',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 30,
                'class'              => 'regular-text',
                'title'              => __( 'Account id', 'dynamic-google-reviews' ),
            ],
            'location_id' => [
                'type'               => 'text',
                'field'              => 'location_id',
                'default'            => '',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 40,
                'class'              => 'regular-text',
                'title'              => __( 'Location id', 'dynamic-google-reviews' ),
            ],
            'min_rating' => [
                'type'               => 'number',
                'field'              => 'min_rating',
                'default'            => 1,
                'min'                => 1,
                'max'                => 5,
                'sanitize_type'      => 'integer',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 50,
                'getter'             => 'get_min_rating',
                'passes_default'     => true,
                'attrs'              => [
                    'min' => '1',
                    'max' => '5',
                ],
                'title'              => __( 'Min rating', 'dynamic-google-reviews' ),
            ],
            'max_reviews' => [
                'type'               => 'number',
                'field'              => 'max_reviews',
                'default'            => 100,
                'min'                => 1,
                'sanitize_type'      => 'integer',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 90,
                'getter'             => 'get_max_reviews',
                'passes_default'     => true,
                'attrs'              => [
                    'min'  => '1',
                    'step' => '1',
                ],
                'title'              => __( 'Max reviews', 'dynamic-google-reviews' ),
                'description'        => __( 'How many reviews to fetch and include in the JSON-LD (older ones are ignored).', 'dynamic-google-reviews' ),
            ],
            'business_name' => [
                'type'               => 'text',
                'field'              => 'business_name',
                'default'            => '',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 60,
                'class'              => 'regular-text',
                'getter'             => 'get_business_name',
                'passes_default'     => true,
                'title'              => __( 'Business name', 'dynamic-google-reviews' ),
                'description'        => __( 'Optional: override the site name used in the LocalBusiness schema.', 'dynamic-google-reviews' ),
            ],
            'address' => [
                'type'               => 'textarea',
                'field'              => 'address',
                'default'            => '',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 70,
                'getter'             => 'get_address',
                'passes_default'     => true,
                'rows'               => '3',
                'cols'               => '40',
                'title'              => __( 'Address', 'dynamic-google-reviews' ),
                'description'        => __( 'Optional: provide a street address to include in the LocalBusiness schema (PostalAddress → streetAddress).', 'dynamic-google-reviews' ),
            ],
            'add_to_multiple' => [
                'type'               => 'checkbox',
                'field'              => 'add_to_multiple',
                'default'            => 0,
                'stored'             => true,
                'register'           => true,
                'registration_order' => 80,
                'getter'             => 'use_add_to_multiple',
                'title'              => __( 'Add to multiple pages', 'dynamic-google-reviews' ),
                'label'              => __( 'Enable adding reviews JSON-LD only to selected pages.', 'dynamic-google-reviews' ),
                'description'        => __( 'Only used when "Add to multiple pages" is enabled.', 'dynamic-google-reviews' ),
            ],
            'selected_pages' => [
                'type'               => 'custom',
                'field'              => 'selected_pages',
                'default'            => [],
                'sanitize_type'      => 'array',
                'items'              => 'positive_integer',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 100,
                'title'              => __( 'Select pages to include rich data on', 'dynamic-google-reviews' ),
            ],
            'remove_tokens' => [
                'type'               => 'custom',
                'field'              => 'remove_tokens',
                'stored'             => false,
                'register'           => true,
                'registration_order' => 110,
                'title'              => __( 'Remove stored tokens', 'dynamic-google-reviews' ),
            ],
            'fetch_interval' => [
                'title'              => __( 'Fetch interval', 'dynamic-google-reviews' ),
                'type'               => 'select',
                'field'              => 'fetch_interval',
                'default'            => 'monthly',
                'fresh_default'      => 'weekly',
                'allowed_values'     => [ 'daily', 'weekly', 'monthly' ],
                'cache_ttl'          => [
                    'daily'   => 2 * DAY_IN_SECONDS,
                    'weekly'  => 2 * WEEK_IN_SECONDS,
                    'monthly' => 45 * DAY_IN_SECONDS,
                ],
                'sanitize_type'      => 'fetch_interval',
                'stored'             => true,
                'register'           => true,
                'registration_order' => 85,
                'getter'             => 'get_fetch_interval',
                'passes_default'     => true,
                'options'            => [
                    'daily'   => __( 'Daily', 'dynamic-google-reviews' ),
                    'weekly'  => __( 'Weekly', 'dynamic-google-reviews' ),
                    'monthly' => __( 'Monthly', 'dynamic-google-reviews' ),
                ],
                'description'        => __( 'How often stored reviews are refreshed automatically.', 'dynamic-google-reviews' ),
            ],
        ];
    }

    public static function get( $field ) {
        $fields = self::all();

        return isset( $fields[ $field ] ) ? $fields[ $field ] : [];
    }

    public static function get_runtime_rules( $field = null ) {
        $rules = [];

        foreach ( self::all() as $field_name => $definition ) {
            if ( ! array_key_exists( 'min', $definition ) && ! array_key_exists( 'max', $definition ) ) {
                continue;
            }

            $rules[ $field_name ] = [
                'default' => $definition['default'],
            ];

            if ( array_key_exists( 'min', $definition ) ) {
                $rules[ $field_name ]['min'] = $definition['min'];
            }

            if ( array_key_exists( 'max', $definition ) ) {
                $rules[ $field_name ]['max'] = $definition['max'];
            }
        }

        if ( null === $field ) {
            return $rules;
        }

        return $rules[ $field ] ?? [];
    }

    public static function get_sanitize_rules( $field = null ) {
        $rules = [];

        foreach ( self::all() as $field_name => $definition ) {
            $rules[ $field_name ] = self::build_sanitize_rule( $definition );
        }

        if ( null === $field ) {
            return $rules;
        }

        return $rules[ $field ] ?? [];
    }

    private static function build_sanitize_rule( $definition ) {
        $field_rules = [
            'stored' => ! empty( $definition['stored'] ),
        ];

        if ( empty( $definition['stored'] ) ) {
            return $field_rules;
        }

        $field_rules['type'] = isset( $definition['sanitize_type'] ) ? $definition['sanitize_type'] : $definition['type'];

        if ( isset( $field_rules['type'] ) && 'array' === $field_rules['type'] ) {
            if ( array_key_exists( 'items', $definition ) ) {
                $field_rules['items'] = $definition['items'];
            }

            $field_rules['default'] = array_key_exists( 'default', $definition ) ? $definition['default'] : '';

            return $field_rules;
        }

        $field_rules['default'] = array_key_exists( 'default', $definition ) ? $definition['default'] : '';

        foreach ( [ 'min', 'max', 'allowed_values' ] as $key ) {
            if ( array_key_exists( $key, $definition ) ) {
                $field_rules[ $key ] = $definition[ $key ];
            }
        }

        return $field_rules;
    }

    /**
     * Schema view consumed by DGR_Admin_Field_Schema. Emits every key
     * from the field definition (minus internal-only keys) plus a
     * 'sanitize' sub-array. We no longer maintain a per-field key-order
     * whitelist — adding a new key to a definition surfaces it
     * automatically.
     */
    public static function get_schema_fields() {
        $fields   = [];
        $internal = self::internal_keys();

        foreach ( self::all() as $field => $definition ) {
            $schema = [];

            foreach ( $definition as $key => $value ) {
                if ( in_array( $key, $internal, true ) ) {
                    continue;
                }
                $schema[ $key ] = $value;
            }

            $schema['sanitize'] = self::build_sanitize_rule( $definition );

            $fields[ $field ] = $schema;
        }

        return $fields;
    }

    /**
     * Definition keys that are used by the registry / sanitize pipeline
     * but should not appear in the admin schema. Keep this list narrow.
     */
    private static function internal_keys() {
        return [
            'sanitize_type',
            'allowed_values',
            'cache_ttl',
            'fresh_default',
            'items',
            'stored',
            'min',
            'max',
        ];
    }
}

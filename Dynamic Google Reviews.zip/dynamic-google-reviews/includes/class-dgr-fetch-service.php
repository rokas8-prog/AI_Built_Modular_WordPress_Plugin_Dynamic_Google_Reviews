<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/class-dgr-logger.php';
require_once __DIR__ . '/class-dgr-oauth-service.php';

class DGR_Fetch_Service {

    public static function http_request( $client, $method, $url, &$tokens, $token_key ) {
        $method   = strtoupper( (string) $method );
        $attempts = 0;

        do {
            $attempts++;
            $code  = 0;
            $body  = '';
            $error = '';

            $http = null;
            if ( is_object( $client ) ) {
                $http = method_exists( $client, 'authorize' ) ? $client->authorize() : ( method_exists( $client, 'getHttpClient' ) ? $client->getHttpClient() : null );
            }

            if ( $http && is_object( $http ) && method_exists( $http, 'request' ) ) {
                try {
                    $resp = $http->request( $method, $url );
                    $code = (int) $resp->getStatusCode();
                    $body = (string) $resp->getBody();
                } catch ( Exception $e ) {
                    return [
                        'code'  => 0,
                        'body'  => '',
                        'error' => $e->getMessage(),
                    ];
                }
            } else {
                $headers = [
                    'Accept' => 'application/json',
                ];
                if ( ! empty( $tokens['access_token'] ) ) {
                    $headers['Authorization'] = 'Bearer ' . $tokens['access_token'];
                }

                $resp = wp_remote_request( $url, [
                    'method'      => $method,
                    'timeout'     => 20,
                    'redirection' => 2,
                    'headers'     => $headers,
                    'user-agent'  => self::user_agent(),
                ] );

                if ( is_wp_error( $resp ) ) {
                    return [
                        'code'  => 0,
                        'body'  => '',
                        'error' => $resp->get_error_message(),
                    ];
                }

                $code = (int) wp_remote_retrieve_response_code( $resp );
                $body = (string) wp_remote_retrieve_body( $resp );
            }

            if ( 401 === $code && 1 === $attempts && DGR_OAuth_Service::refresh_access_token( $client, $tokens, $token_key ) ) {
                if ( is_object( $client ) && method_exists( $client, 'setAccessToken' ) ) {
                    try {
                        $client->setAccessToken( $tokens );
                    } catch ( Exception $e ) {
                        DGR_Logger::log( 'setAccessToken after refresh failed: ' . $e->getMessage() );
                    }
                }
                continue;
            }

            return [
                'code'  => $code,
                'body'  => $body,
                'error' => $error,
            ];
        } while ( $attempts < 2 );

        return [
            'code'  => 0,
            'body'  => '',
            'error' => 'Unknown request error.',
        ];
    }

    public static function resolve_location_id_from_place_id( $client, $account_id, $maybe_place_id, &$tokens, $token_key ) {
        if ( stripos( $maybe_place_id, 'ChI' ) !== 0 ) {
            return null;
        }

        $base = sprintf(
            'https://mybusinessbusinessinformation.googleapis.com/v1/accounts/%s/locations',
            rawurlencode( $account_id )
        );

        $pageToken = null;
        do {
            $query = array_filter( [
                'readMask'  => 'name,placeId',
                'pageSize'  => 100,
                'pageToken' => $pageToken,
            ] );
            $url  = $base . '?' . http_build_query( $query );
            $resp = self::http_request( $client, 'GET', $url, $tokens, $token_key );

            if ( 200 !== (int) $resp['code'] ) {
                DGR_Logger::log( 'Resolve place ID HTTP code: ' . (int) $resp['code'] . '. err=' . $resp['error'] );
                break;
            }

            $json = json_decode( (string) $resp['body'], true );
            if ( ! is_array( $json ) ) {
                DGR_Logger::log( 'Resolve place ID JSON decode failed.' );
                break;
            }

            if ( ! empty( $json['locations'] ) ) {
                foreach ( $json['locations'] as $loc ) {
                    if ( isset( $loc['placeId'] ) && $loc['placeId'] === $maybe_place_id && isset( $loc['name'] ) ) {
                        $parts    = explode( '/', $loc['name'] );
                        $resolved = end( $parts );
                        if ( $resolved ) {
                            return sanitize_text_field( $resolved );
                        }
                    }
                }
            }

            $pageToken = $json['nextPageToken'] ?? null;
        } while ( $pageToken );

        return null;
    }

    /**
     * Fetch reviews from the Google Business Profile API.
     *
     * Reviews are only exposed via the legacy v4 endpoint
     * (https://mybusiness.googleapis.com/v4/accounts/{aid}/locations/{lid}/reviews).
     * The newer mybusinessbusinessinformation v1 / businessprofile v1 surfaces do
     * not include a reviews resource, so we no longer attempt v1 fallbacks.
     */
    public static function fetch_reviews( $opts, &$tokens, $token_key ) {
        $maxReviews = self::get_max_reviews_limit( $opts );

        $client = self::prepare_google_client_for_fetch( $opts, $tokens, $token_key );
        if ( ! $client ) {
            return null;
        }

        $resolved_location_id = self::resolve_configured_location_id( $client, $opts, $tokens, $token_key );

        $fetch_result = self::fetch_review_flow(
            $client,
            $opts,
            $tokens,
            $token_key,
            $maxReviews
        );

        return self::build_fetch_result(
            $fetch_result['reviews'],
            $fetch_result['did_any_request_succeed'],
            $resolved_location_id,
            $maxReviews,
            $fetch_result['last_http_code'],
            $fetch_result['last_error']
        );
    }

    /**
     * Lightweight credential / connectivity probe used by the admin "Test
     * connection" button. Performs a single small request that doesn't
     * mutate stored reviews and reports a normalized status code + body
     * snippet that the admin layer can render.
     */
    public static function test_connection( $opts, &$tokens, $token_key ) {
        $client = self::prepare_google_client_for_fetch( $opts, $tokens, $token_key );
        if ( ! $client ) {
            return [
                'ok'      => false,
                'code'    => 'client_unavailable',
                'http'    => 0,
                'message' => __( 'Could not instantiate the OAuth client. Check Client ID / Client secret.', 'dynamic-google-reviews' ),
            ];
        }

        $url = self::build_v4_reviews_url( $opts, [
            'pageSize' => 1,
        ] );

        $resp      = self::http_request( $client, 'GET', $url, $tokens, $token_key );
        $http_code = (int) ( $resp['code'] ?? 0 );

        if ( 200 === $http_code ) {
            return [
                'ok'      => true,
                'code'    => 'ok',
                'http'    => 200,
                'message' => __( 'Connection successful — the v4 reviews endpoint responded with HTTP 200.', 'dynamic-google-reviews' ),
            ];
        }

        $body_snippet = self::extract_api_error_snippet( (string) ( $resp['body'] ?? '' ) );

        return [
            'ok'      => false,
            'code'    => 'http_' . $http_code,
            'http'    => $http_code,
            'message' => $body_snippet
                ? sprintf( __( 'HTTP %1$d. %2$s', 'dynamic-google-reviews' ), $http_code, $body_snippet )
                : sprintf( __( 'HTTP %d. See logs for details (enable the dgr_bp_enable_logging filter).', 'dynamic-google-reviews' ), $http_code ),
        ];
    }

    private static function extract_api_error_snippet( $body ) {
        if ( '' === $body ) {
            return '';
        }

        $json = json_decode( $body, true );
        if ( is_array( $json ) ) {
            if ( isset( $json['error']['message'] ) && is_string( $json['error']['message'] ) ) {
                return sanitize_text_field( $json['error']['message'] );
            }
            if ( isset( $json['error_description'] ) && is_string( $json['error_description'] ) ) {
                return sanitize_text_field( $json['error_description'] );
            }
            if ( isset( $json['error'] ) && is_string( $json['error'] ) ) {
                return sanitize_text_field( $json['error'] );
            }
        }

        return sanitize_text_field( substr( $body, 0, 200 ) );
    }

    private static function user_agent() {
        $version = defined( 'DGR_VERSION' ) ? DGR_VERSION : 'dev';

        return 'DynamicGoogleReviews/' . $version . ' (WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url( '/' ) . ')';
    }

    private static function get_max_reviews_limit( $opts ) {
        return isset( $opts['max_reviews'] ) ? max( 1, intval( $opts['max_reviews'] ) ) : 100;
    }

    private static function prepare_google_client_for_fetch( $opts, &$tokens, $token_key ) {
        $client = DGR_OAuth_Service::create_google_client( $opts, $tokens, $token_key );
        if ( ! $client ) {
            DGR_Logger::log( 'create_google_client returned null.' );
            return null;
        }

        return $client;
    }

    private static function resolve_configured_location_id( $client, &$opts, &$tokens, $token_key ) {
        $resolved_location_id = null;

        if ( stripos( $opts['location_id'], 'ChI' ) === 0 ) {
            $resolved = self::resolve_location_id_from_place_id( $client, $opts['account_id'], $opts['location_id'], $tokens, $token_key );
            if ( $resolved ) {
                $resolved_location_id = $resolved;
                $opts['location_id'] = $resolved;
            }
        }

        return $resolved_location_id;
    }

    private static function build_v4_reviews_url( $opts, $query ) {
        $base = sprintf(
            'https://mybusiness.googleapis.com/v4/accounts/%s/locations/%s/reviews',
            rawurlencode( $opts['account_id'] ),
            rawurlencode( $opts['location_id'] )
        );

        return $base . '?' . http_build_query( $query );
    }

    private static function build_v4_reviews_query( $pageSize, $pageTok ) {
        return array_filter( [
            'orderBy'   => 'updateTime desc',
            'pageSize'  => $pageSize,
            'fields'    => 'reviews(reviewId,starRating,comment,reviewer(displayName),createTime,updateTime),nextPageToken',
            'pageToken' => $pageTok,
        ] );
    }

    private static function build_v4_reviews_log_context( $opts, $query ) {
        return [
            'endpoint'           => 'google_business_profile_reviews_v4',
            'url_path_template'  => '/v4/accounts/{account_id}/locations/{location_id}/reviews',
            'account_id_masked'  => self::mask_log_identifier( $opts['account_id'] ?? '' ),
            'location_id_masked' => self::mask_log_identifier( $opts['location_id'] ?? '' ),
            'page_size'          => isset( $query['pageSize'] ) ? (int) $query['pageSize'] : 0,
            'has_page_token'     => ! empty( $query['pageToken'] ),
            'has_fields_filter'  => ! empty( $query['fields'] ),
        ];
    }

    private static function mask_log_identifier( $value ) {
        $value  = (string) $value;
        $length = strlen( $value );

        if ( 0 === $length ) {
            return '';
        }

        if ( $length <= 4 ) {
            return str_repeat( '*', $length );
        }

        return substr( $value, 0, 2 ) . str_repeat( '*', $length - 4 ) . substr( $value, -2 );
    }

    private static function fetch_review_flow( $client, $opts, &$tokens, $token_key, $maxReviews ) {
        $all                     = [];
        $did_any_request_succeed = false;
        $last_http_code          = 0;
        $last_error              = '';
        $pageTok                 = null;

        do {
            $pageSize = min( 100, max( 1, $maxReviews - count( $all ) ) );
            $query    = self::build_v4_reviews_query( $pageSize, $pageTok );
            $url      = self::build_v4_reviews_url( $opts, $query );
            DGR_Logger::log_context( 'Requesting v4 reviews endpoint.', self::build_v4_reviews_log_context( $opts, $query ) );

            $resp           = self::http_request( $client, 'GET', $url, $tokens, $token_key );
            $last_http_code = (int) $resp['code'];
            $last_error     = (string) ( $resp['error'] ?? '' );

            if ( 200 !== $last_http_code ) {
                DGR_Logger::log( "v4 HTTP code: {$last_http_code}. len=" . strlen( (string) $resp['body'] ) . ". err=" . $last_error );
                break;
            }

            $did_any_request_succeed = true;

            $json = json_decode( (string) $resp['body'], true );
            if ( self::append_reviews_from_response( $json, $all, $maxReviews ) ) {
                break;
            }

            $pageTok = $json['nextPageToken'] ?? null;
        } while ( $pageTok && count( $all ) < $maxReviews );

        return [
            'reviews'                 => $all,
            'did_any_request_succeed' => $did_any_request_succeed,
            'last_http_code'          => $last_http_code,
            'last_error'              => $last_error,
        ];
    }

    private static function append_reviews_from_response( $json, &$all, $maxReviews ) {
        if ( ! empty( $json['reviews'] ) ) {
            foreach ( $json['reviews'] as $r ) {
                $all[] = $r;
                if ( count( $all ) >= $maxReviews ) { return true; }
            }
        }

        return false;
    }

    private static function build_fetch_result( $all, $did_any_request_succeed, $resolved_location_id, $maxReviews, $last_http_code = 0, $last_error = '' ) {
        if ( empty( $all ) && ! $did_any_request_succeed ) {
            DGR_Logger::log( 'Fetch failed (no successful responses). Keeping existing stored reviews.' );
            return [
                'reviews'              => [],
                'persist'              => false,
                'resolved_location_id' => $resolved_location_id,
                'max_reviews'          => $maxReviews,
                'last_http_code'       => $last_http_code,
                'last_error'           => $last_error,
            ];
        }

        return [
            'reviews'              => $all,
            'persist'              => true,
            'resolved_location_id' => $resolved_location_id,
            'max_reviews'          => $maxReviews,
            'last_http_code'       => $last_http_code,
            'last_error'           => $last_error,
        ];
    }

}
